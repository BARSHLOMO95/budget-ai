import { format, startOfMonth, endOfMonth, isWithinInterval, parseISO } from 'date-fns';
import { he } from 'date-fns/locale';
import { clsx, type ClassValue } from 'clsx';
import type { Currency } from '@/types';

// ============================================================
// MONTH NAMES (Hebrew)
// ============================================================

export const MONTH_NAMES_HE = [
  'ינואר',
  'פברואר',
  'מרץ',
  'אפריל',
  'מאי',
  'יוני',
  'יולי',
  'אוגוסט',
  'ספטמבר',
  'אוקטובר',
  'נובמבר',
  'דצמבר',
];

// ============================================================
// CLASS NAME UTILITIES
// ============================================================

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

// ============================================================
// CURRENCY FORMATTING
// ============================================================

const currencySymbols: Record<Currency, string> = {
  ILS: '₪',
  USD: '$',
  EUR: '€',
};

export function formatCurrency(
  amount: number,
  currency: Currency = 'ILS',
  options?: {
    showSign?: boolean;
    compact?: boolean;
  }
): string {
  const { showSign = false, compact = false } = options || {};
  
  const symbol = currencySymbols[currency];
  const absAmount = Math.abs(amount);
  
  let formatted: string;
  
  if (compact && absAmount >= 1000) {
    if (absAmount >= 1000000) {
      formatted = `${(absAmount / 1000000).toFixed(1)}M`;
    } else if (absAmount >= 1000) {
      formatted = `${(absAmount / 1000).toFixed(absAmount >= 10000 ? 0 : 1)}K`;
    } else {
      formatted = absAmount.toLocaleString('he-IL');
    }
  } else {
    formatted = absAmount.toLocaleString('he-IL', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });
  }
  
  const sign = showSign ? (amount > 0 ? '+' : amount < 0 ? '-' : '') : (amount < 0 ? '-' : '');
  
  // For RTL, symbol comes after the number
  return `${sign}${formatted} ${symbol}`;
}

export function parseCurrencyInput(value: string): number {
  // Remove currency symbols and thousands separators
  const cleaned = value
    .replace(/[₪$€,\s]/g, '')
    .replace(/,/g, '.');
  
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? 0 : parsed;
}

// ============================================================
// DATE FORMATTING
// ============================================================

export function formatDate(date: Date | string, pattern: string = 'dd/MM/yyyy'): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, pattern, { locale: he });
}

export function formatDateRelative(date: Date | string): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return 'היום';
  if (diffDays === 1) return 'אתמול';
  if (diffDays < 7) return `לפני ${diffDays} ימים`;
  if (diffDays < 30) return `לפני ${Math.floor(diffDays / 7)} שבועות`;
  
  return formatDate(d);
}

export function formatMonth(month: number, year: number): string {
  return `${MONTH_NAMES_HE[month]} ${year}`;
}

export function getMonthRange(month: number, year: number): { start: Date; end: Date } {
  const date = new Date(year, month, 1);
  return {
    start: startOfMonth(date),
    end: endOfMonth(date),
  };
}

export function isDateInRange(
  date: Date,
  start: Date | null,
  end: Date | null
): boolean {
  if (!start && !end) return true;
  if (!start) return date <= end!;
  if (!end) return date >= start;
  return isWithinInterval(date, { start, end });
}

export function getCurrentMonthYear(): { month: number; year: number } {
  const now = new Date();
  return {
    month: now.getMonth(),
    year: now.getFullYear(),
  };
}

// ============================================================
// NUMBER FORMATTING
// ============================================================

export function formatPercent(value: number, decimals: number = 0): string {
  return `${value.toFixed(decimals)}%`;
}

export function formatNumber(value: number): string {
  return value.toLocaleString('he-IL');
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

// ============================================================
// STRING UTILITIES
// ============================================================

export function normalizeSearch(text: string): string {
  return text.toLowerCase().trim();
}

export function searchMatch(text: string, query: string): boolean {
  if (!query) return true;
  return normalizeSearch(text).includes(normalizeSearch(query));
}

export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return `${text.slice(0, maxLength)}...`;
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// ============================================================
// VALIDATION UTILITIES
// ============================================================

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function isValidAmount(value: string | number): boolean {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  return !isNaN(num) && num > 0 && isFinite(num);
}

// ============================================================
// COLOR UTILITIES
// ============================================================

export function hexToRgba(hex: string, alpha: number = 1): string {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) return `rgba(0, 0, 0, ${alpha})`;
  
  return `rgba(${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}, ${alpha})`;
}

export function getContrastColor(hexColor: string): 'white' | 'black' {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hexColor);
  if (!result) return 'black';
  
  const r = parseInt(result[1], 16);
  const g = parseInt(result[2], 16);
  const b = parseInt(result[3], 16);
  
  // Calculate relative luminance
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.5 ? 'black' : 'white';
}

// ============================================================
// DEBOUNCE UTILITY
// ============================================================

export function debounce<T extends (...args: unknown[]) => unknown>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeoutId: ReturnType<typeof setTimeout> | null = null;
  
  return (...args: Parameters<T>) => {
    if (timeoutId) {
      clearTimeout(timeoutId);
    }
    
    timeoutId = setTimeout(() => {
      func(...args);
    }, wait);
  };
}

// ============================================================
// STORAGE UTILITIES
// ============================================================

export function getLocalStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

export function setLocalStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    console.error('Failed to save to localStorage');
  }
}

// ============================================================
// ARRAY UTILITIES
// ============================================================

export function groupBy<T>(
  array: T[],
  keyFn: (item: T) => string
): Record<string, T[]> {
  return array.reduce((acc, item) => {
    const key = keyFn(item);
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(item);
    return acc;
  }, {} as Record<string, T[]>);
}

export function sortBy<T>(
  array: T[],
  keyFn: (item: T) => number | string,
  direction: 'asc' | 'desc' = 'asc'
): T[] {
  return [...array].sort((a, b) => {
    const aVal = keyFn(a);
    const bVal = keyFn(b);
    
    if (aVal < bVal) return direction === 'asc' ? -1 : 1;
    if (aVal > bVal) return direction === 'asc' ? 1 : -1;
    return 0;
  });
}

export function sumBy<T>(array: T[], keyFn: (item: T) => number): number {
  return array.reduce((sum, item) => sum + keyFn(item), 0);
}
