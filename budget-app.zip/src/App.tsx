import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, WorkspaceProvider, useAuth } from '@/hooks';
import { AppLayout } from '@/components/layout';
import { LoginPage, SignUpPage } from '@/components/auth';
import { DashboardPage } from '@/pages/DashboardPage';
import { TransactionsPage } from '@/pages/TransactionsPage';
import { Spinner } from '@/components/ui';

// Protected Route wrapper
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-50">
        <div className="text-center">
          <Spinner size="lg" className="text-primary-500 mx-auto" />
          <p className="mt-4 text-surface-500">טוען...</p>
        </div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
}

// Public Route wrapper (redirects to home if logged in)
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-50">
        <div className="text-center">
          <Spinner size="lg" className="text-primary-500 mx-auto" />
          <p className="mt-4 text-surface-500">טוען...</p>
        </div>
      </div>
    );
  }
  
  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
}

// Placeholder pages
function CategoriesPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-display font-bold text-surface-900">קטגוריות</h1>
      <p className="text-surface-500">ניהול קטגוריות יהיה זמין בקרוב...</p>
    </div>
  );
}

function ReportsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-display font-bold text-surface-900">דוחות</h1>
      <p className="text-surface-500">דוחות מתקדמים יהיו זמינים בקרוב...</p>
    </div>
  );
}

function SettingsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-display font-bold text-surface-900">הגדרות</h1>
      <p className="text-surface-500">הגדרות יהיו זמינות בקרוב...</p>
    </div>
  );
}

function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route
        path="/login"
        element={
          <PublicRoute>
            <LoginPage />
          </PublicRoute>
        }
      />
      <Route
        path="/signup"
        element={
          <PublicRoute>
            <SignUpPage />
          </PublicRoute>
        }
      />
      
      {/* Protected routes */}
      <Route
        element={
          <ProtectedRoute>
            <WorkspaceProvider>
              <AppLayout />
            </WorkspaceProvider>
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardPage />} />
        <Route path="transactions" element={<TransactionsPage />} />
        <Route path="categories" element={<CategoriesPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="settings/billing" element={<SettingsPage />} />
      </Route>
      
      {/* 404 */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
