import type {
  Transaction,
  TransactionWithCategory,
  Category,
  MonthlyTotals,
  CategorySummary,
  MonthlyReport,
  TransactionFilters,
  QuickFilters,
  AdvancedFilters,
} from '@/types';
import { groupBy, sumBy, sortBy } from '@/utils';
import { isDateInRange, searchMatch } from '@/utils';

// ============================================================
// MONTHLY TOTALS CALCULATION
// ============================================================

export function calculateMonthlyTotals(
  transactions: Transaction[],
  categories: Category[]
): MonthlyTotals {
  const categoryMap = new Map(categories.map((cat) => [cat.id, cat]));
  
  let income = 0;
  let expense = 0;
  let fixedExpenses = 0;
  let variableExpenses = 0;
  
  for (const tx of transactions) {
    const category = categoryMap.get(tx.categoryId);
    
    if (tx.type === 'income') {
      income += tx.amount;
    } else {
      expense += tx.amount;
      
      if (category) {
        if (category.group === 'fixed') {
          fixedExpenses += tx.amount;
        } else {
          variableExpenses += tx.amount;
        }
      }
    }
  }
  
  return {
    income,
    expense,
    balance: income - expense,
    fixedExpenses,
    variableExpenses,
  };
}

// ============================================================
// CATEGORY SUMMARY CALCULATION
// ============================================================

export function calculateCategorySummaries(
  transactions: Transaction[],
  categories: Category[],
  type: 'income' | 'expense' | 'all' = 'all'
): CategorySummary[] {
  const filteredCategories = type === 'all'
    ? categories
    : categories.filter((cat) => cat.type === type);
  
  const categoryMap = new Map(filteredCategories.map((cat) => [cat.id, cat]));
  
  const byCategory = groupBy(transactions, (tx) => tx.categoryId);
  
  const totalAmount = type === 'all'
    ? sumBy(transactions, (tx) => tx.amount)
    : sumBy(
        transactions.filter((tx) => tx.type === type),
        (tx) => tx.amount
      );
  
  const summaries: CategorySummary[] = [];
  
  for (const category of filteredCategories) {
    const categoryTxs = byCategory[category.id] || [];
    const total = sumBy(categoryTxs, (tx) => tx.amount);
    
    if (total > 0 || category.targetMonthly) {
      const percentOfTarget = category.targetMonthly
        ? (total / category.targetMonthly) * 100
        : null;
      
      summaries.push({
        categoryId: category.id,
        category,
        total,
        count: categoryTxs.length,
        percentOfTotal: totalAmount > 0 ? (total / totalAmount) * 100 : 0,
        targetMonthly: category.targetMonthly,
        percentOfTarget,
        isOverBudget: percentOfTarget !== null && percentOfTarget > 100,
      });
    }
  }
  
  return sortBy(summaries, (s) => s.total, 'desc');
}

// ============================================================
// MONTHLY REPORT GENERATION
// ============================================================

export function generateMonthlyReport(
  transactions: Transaction[],
  categories: Category[],
  month: number,
  year: number,
  previousMonthTransactions?: Transaction[]
): MonthlyReport {
  const totals = calculateMonthlyTotals(transactions, categories);
  const byCategory = calculateCategorySummaries(transactions, categories);
  
  let previousMonthTotals: MonthlyTotals | undefined;
  let changeFromPrevious: MonthlyReport['changeFromPrevious'];
  
  if (previousMonthTransactions) {
    previousMonthTotals = calculateMonthlyTotals(previousMonthTransactions, categories);
    
    changeFromPrevious = {
      income: previousMonthTotals.income > 0
        ? ((totals.income - previousMonthTotals.income) / previousMonthTotals.income) * 100
        : 0,
      expense: previousMonthTotals.expense > 0
        ? ((totals.expense - previousMonthTotals.expense) / previousMonthTotals.expense) * 100
        : 0,
      balance: previousMonthTotals.balance !== 0
        ? ((totals.balance - previousMonthTotals.balance) / Math.abs(previousMonthTotals.balance)) * 100
        : 0,
    };
  }
  
  return {
    month,
    year,
    totals,
    byCategory,
    previousMonthTotals,
    changeFromPrevious,
  };
}

// ============================================================
// TRANSACTION FILTERING (CLIENT-SIDE)
// ============================================================

export function applyQuickFilters(
  transactions: Transaction[],
  categories: Category[],
  filters: QuickFilters
): Transaction[] {
  const categoryMap = new Map(categories.map((cat) => [cat.id, cat]));
  
  return transactions.filter((tx) => {
    // Type filter
    if (filters.type !== 'all' && tx.type !== filters.type) {
      return false;
    }
    
    // Category filter
    if (filters.categoryId !== 'all' && tx.categoryId !== filters.categoryId) {
      return false;
    }
    
    // Group filter (fixed/variable)
    if (filters.group !== 'all') {
      const category = categoryMap.get(tx.categoryId);
      if (!category || category.group !== filters.group) {
        return false;
      }
    }
    
    return true;
  });
}

export function applyAdvancedFilters(
  transactions: Transaction[],
  filters: AdvancedFilters
): Transaction[] {
  return transactions.filter((tx) => {
    // Date range filter
    if (filters.dateFrom || filters.dateTo) {
      if (!isDateInRange(tx.date, filters.dateFrom, filters.dateTo)) {
        return false;
      }
    }
    
    // Amount range filter
    if (filters.amountMin !== null && tx.amount < filters.amountMin) {
      return false;
    }
    if (filters.amountMax !== null && tx.amount > filters.amountMax) {
      return false;
    }
    
    // Search filter (case-insensitive)
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      const matchesDescription = tx.description.toLowerCase().includes(searchTerm);
      const matchesNotes = tx.notes?.toLowerCase().includes(searchTerm);
      const matchesTags = tx.tags.some((tag) => tag.toLowerCase().includes(searchTerm));
      
      if (!matchesDescription && !matchesNotes && !matchesTags) {
        return false;
      }
    }
    
    // Tags filter
    if (filters.tags.length > 0) {
      const hasTags = filters.tags.some((tag) =>
        tx.tags.map((t) => t.toLowerCase()).includes(tag.toLowerCase())
      );
      if (!hasTags) {
        return false;
      }
    }
    
    return true;
  });
}

export function applyAllFilters(
  transactions: Transaction[],
  categories: Category[],
  filters: TransactionFilters
): Transaction[] {
  let result = applyQuickFilters(transactions, categories, filters.quick);
  result = applyAdvancedFilters(result, filters.advanced);
  return result;
}

// ============================================================
// ENRICHMENT
// ============================================================

export function enrichTransactionsWithCategories(
  transactions: Transaction[],
  categories: Category[]
): TransactionWithCategory[] {
  const categoryMap = new Map(categories.map((cat) => [cat.id, cat]));
  
  return transactions.map((tx) => ({
    ...tx,
    category: categoryMap.get(tx.categoryId) || null,
  }));
}

// ============================================================
// ANALYTICS
// ============================================================

export function calculateSpendingTrend(
  currentMonthTotal: number,
  previousMonthTotal: number
): { change: number; trend: 'up' | 'down' | 'stable' } {
  if (previousMonthTotal === 0) {
    return { change: 0, trend: 'stable' };
  }
  
  const change = ((currentMonthTotal - previousMonthTotal) / previousMonthTotal) * 100;
  
  return {
    change,
    trend: change > 5 ? 'up' : change < -5 ? 'down' : 'stable',
  };
}

export function calculateBudgetHealth(
  totals: MonthlyTotals,
  categorySummaries: CategorySummary[]
): {
  score: number; // 0-100
  status: 'excellent' | 'good' | 'warning' | 'danger';
  insights: string[];
} {
  const insights: string[] = [];
  let score = 100;
  
  // Savings rate analysis
  const savingsRate = totals.income > 0
    ? (totals.balance / totals.income) * 100
    : 0;
  
  if (savingsRate < 0) {
    score -= 30;
    insights.push('ההוצאות גבוהות מההכנסות');
  } else if (savingsRate < 10) {
    score -= 15;
    insights.push('שיעור החיסכון נמוך');
  } else if (savingsRate >= 20) {
    insights.push('שיעור חיסכון מצוין!');
  }
  
  // Over-budget categories
  const overBudgetCategories = categorySummaries.filter((s) => s.isOverBudget);
  if (overBudgetCategories.length > 0) {
    score -= overBudgetCategories.length * 10;
    insights.push(`${overBudgetCategories.length} קטגוריות חרגו מהתקציב`);
  }
  
  // Fixed vs variable ratio
  const fixedRatio = totals.expense > 0
    ? (totals.fixedExpenses / totals.expense) * 100
    : 0;
  
  if (fixedRatio > 70) {
    score -= 10;
    insights.push('שיעור ההוצאות הקבועות גבוה');
  }
  
  score = Math.max(0, Math.min(100, score));
  
  let status: 'excellent' | 'good' | 'warning' | 'danger';
  if (score >= 80) status = 'excellent';
  else if (score >= 60) status = 'good';
  else if (score >= 40) status = 'warning';
  else status = 'danger';
  
  return { score, status, insights };
}

// ============================================================
// DEFAULT FILTER STATE
// ============================================================

export function getDefaultQuickFilters(): QuickFilters {
  const now = new Date();
  return {
    month: now.getMonth(),
    year: now.getFullYear(),
    type: 'all',
    group: 'all',
    categoryId: 'all',
  };
}

export function getDefaultAdvancedFilters(): AdvancedFilters {
  return {
    dateFrom: null,
    dateTo: null,
    amountMin: null,
    amountMax: null,
    search: '',
    tags: [],
  };
}

export function getDefaultFilters(): TransactionFilters {
  return {
    quick: getDefaultQuickFilters(),
    advanced: getDefaultAdvancedFilters(),
  };
}
