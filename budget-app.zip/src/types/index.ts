// ============================================================
// USER TYPES
// ============================================================

export type SubscriptionPlan = 'free' | 'pro' | 'pro_business';

export interface User {
  uid: string;
  email: string;
  displayName: string | null;
  photoURL: string | null;
  plan: SubscriptionPlan;
  defaultWorkspaceId: string | null;
  stripeCustomerId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserDoc {
  email: string;
  displayName: string | null;
  photoURL: string | null;
  plan: SubscriptionPlan;
  defaultWorkspaceId: string | null;
  stripeCustomerId: string | null;
  createdAt: FirebaseTimestamp;
  updatedAt: FirebaseTimestamp;
}

// ============================================================
// WORKSPACE TYPES
// ============================================================

export type WorkspaceType = 'personal' | 'business';
export type Currency = 'ILS' | 'USD' | 'EUR';
export type MemberRole = 'owner' | 'admin' | 'member' | 'viewer';

export interface Workspace {
  id: string;
  name: string;
  type: WorkspaceType;
  ownerId: string;
  currency: Currency;
  icon: string;
  color: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface WorkspaceDoc {
  name: string;
  type: WorkspaceType;
  ownerId: string;
  currency: Currency;
  icon: string;
  color: string;
  createdAt: FirebaseTimestamp;
  updatedAt: FirebaseTimestamp;
}

export interface WorkspaceMember {
  id: string;
  workspaceId: string;
  userId: string;
  role: MemberRole;
  email: string;
  displayName: string | null;
  joinedAt: Date;
}

export interface WorkspaceMemberDoc {
  userId: string;
  role: MemberRole;
  email: string;
  displayName: string | null;
  joinedAt: FirebaseTimestamp;
}

// ============================================================
// CATEGORY TYPES
// ============================================================

export type TransactionType = 'income' | 'expense';
export type CategoryGroup = 'fixed' | 'variable';

export interface Category {
  id: string;
  workspaceId: string;
  type: TransactionType;
  group: CategoryGroup;
  label: string;
  labelEn?: string;
  targetMonthly: number | null;
  color: string;
  icon: string;
  order: number;
  isArchived: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface CategoryDoc {
  type: TransactionType;
  group: CategoryGroup;
  label: string;
  labelEn?: string;
  targetMonthly: number | null;
  color: string;
  icon: string;
  order: number;
  isArchived: boolean;
  createdAt: FirebaseTimestamp;
  updatedAt: FirebaseTimestamp;
}

// ============================================================
// TRANSACTION TYPES
// ============================================================

export interface Transaction {
  id: string;
  workspaceId: string;
  type: TransactionType;
  amount: number;
  categoryId: string;
  description: string;
  date: Date;
  isRecurring: boolean;
  recurringId?: string;
  tags: string[];
  notes?: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TransactionDoc {
  type: TransactionType;
  amount: number;
  categoryId: string;
  description: string;
  date: FirebaseTimestamp;
  isRecurring: boolean;
  recurringId?: string;
  tags: string[];
  notes?: string;
  createdBy: string;
  createdAt: FirebaseTimestamp;
  updatedAt: FirebaseTimestamp;
}

export interface TransactionWithCategory extends Transaction {
  category: Category | null;
}

// ============================================================
// FILTER TYPES
// ============================================================

export interface QuickFilters {
  month: number; // 0-11
  year: number;
  type: TransactionType | 'all';
  group: CategoryGroup | 'all';
  categoryId: string | 'all';
}

export interface AdvancedFilters {
  dateFrom: Date | null;
  dateTo: Date | null;
  amountMin: number | null;
  amountMax: number | null;
  search: string;
  tags: string[];
}

export interface TransactionFilters {
  quick: QuickFilters;
  advanced: AdvancedFilters;
}

// ============================================================
// CALCULATION TYPES
// ============================================================

export interface MonthlyTotals {
  income: number;
  expense: number;
  balance: number;
  fixedExpenses: number;
  variableExpenses: number;
}

export interface CategorySummary {
  categoryId: string;
  category: Category;
  total: number;
  count: number;
  percentOfTotal: number;
  targetMonthly: number | null;
  percentOfTarget: number | null;
  isOverBudget: boolean;
}

export interface MonthlyReport {
  month: number;
  year: number;
  totals: MonthlyTotals;
  byCategory: CategorySummary[];
  previousMonthTotals?: MonthlyTotals;
  changeFromPrevious?: {
    income: number;
    expense: number;
    balance: number;
  };
}

// ============================================================
// UI TYPES
// ============================================================

export interface SelectOption<T = string> {
  value: T;
  label: string;
  icon?: string;
}

export interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  duration?: number;
}

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export interface ConfirmDialogProps extends ModalProps {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  variant?: 'danger' | 'warning' | 'info';
  onConfirm: () => void;
}

// ============================================================
// FIREBASE HELPER TYPES
// ============================================================

export interface FirebaseTimestamp {
  toDate: () => Date;
  seconds: number;
  nanoseconds: number;
}

export type FirestoreDataConverter<T, D> = {
  toFirestore: (data: Omit<T, 'id'>) => D;
  fromFirestore: (snapshot: { id: string; data: () => D }) => T;
};

// ============================================================
// API RESPONSE TYPES
// ============================================================

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  hasMore: boolean;
  lastDoc: unknown;
}

// ============================================================
// STRIPE TYPES
// ============================================================

export interface SubscriptionDetails {
  plan: SubscriptionPlan;
  status: 'active' | 'canceled' | 'past_due' | 'trialing';
  currentPeriodEnd: Date;
  cancelAtPeriodEnd: boolean;
}

export interface PlanFeatures {
  maxWorkspaces: number;
  maxMembersPerWorkspace: number;
  hasBusinessWorkspace: boolean;
  hasAdvancedReports: boolean;
  hasExport: boolean;
}

export const PLAN_FEATURES: Record<SubscriptionPlan, PlanFeatures> = {
  free: {
    maxWorkspaces: 1,
    maxMembersPerWorkspace: 2,
    hasBusinessWorkspace: false,
    hasAdvancedReports: false,
    hasExport: false,
  },
  pro: {
    maxWorkspaces: 3,
    maxMembersPerWorkspace: 5,
    hasBusinessWorkspace: false,
    hasAdvancedReports: true,
    hasExport: true,
  },
  pro_business: {
    maxWorkspaces: 10,
    maxMembersPerWorkspace: 10,
    hasBusinessWorkspace: true,
    hasAdvancedReports: true,
    hasExport: true,
  },
};

// ============================================================
// CONSTANTS
// ============================================================

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  ILS: '₪',
  USD: '$',
  EUR: '€',
};

export const MONTH_NAMES_HE = [
  'ינואר',
  'פברואר',
  'מרץ',
  'אפריל',
  'מאי',
  'יוני',
  'יולי',
  'אוגוסט',
  'ספטמבר',
  'אוקטובר',
  'נובמבר',
  'דצמבר',
];

export const DEFAULT_CATEGORIES: Omit<CategoryDoc, 'createdAt' | 'updatedAt'>[] = [
  // Fixed Expenses
  { type: 'expense', group: 'fixed', label: 'שכירות / משכנתא', icon: '🏠', color: '#6366f1', targetMonthly: null, order: 0, isArchived: false },
  { type: 'expense', group: 'fixed', label: 'ביטוח', icon: '🛡️', color: '#8b5cf6', targetMonthly: null, order: 1, isArchived: false },
  { type: 'expense', group: 'fixed', label: 'חשמל', icon: '⚡', color: '#f59e0b', targetMonthly: null, order: 2, isArchived: false },
  { type: 'expense', group: 'fixed', label: 'מים', icon: '💧', color: '#06b6d4', targetMonthly: null, order: 3, isArchived: false },
  { type: 'expense', group: 'fixed', label: 'גז', icon: '🔥', color: '#ef4444', targetMonthly: null, order: 4, isArchived: false },
  { type: 'expense', group: 'fixed', label: 'אינטרנט וטלפון', icon: '📱', color: '#3b82f6', targetMonthly: null, order: 5, isArchived: false },
  { type: 'expense', group: 'fixed', label: 'ועד בית', icon: '🏢', color: '#64748b', targetMonthly: null, order: 6, isArchived: false },
  
  // Variable Expenses
  { type: 'expense', group: 'variable', label: 'סופר / מזון', icon: '🛒', color: '#22c55e', targetMonthly: 2000, order: 10, isArchived: false },
  { type: 'expense', group: 'variable', label: 'מסעדות וקפה', icon: '☕', color: '#f97316', targetMonthly: 500, order: 11, isArchived: false },
  { type: 'expense', group: 'variable', label: 'דלק / תחבורה', icon: '⛽', color: '#eab308', targetMonthly: 800, order: 12, isArchived: false },
  { type: 'expense', group: 'variable', label: 'קניות וביגוד', icon: '👕', color: '#ec4899', targetMonthly: 500, order: 13, isArchived: false },
  { type: 'expense', group: 'variable', label: 'בריאות', icon: '💊', color: '#14b8a6', targetMonthly: 300, order: 14, isArchived: false },
  { type: 'expense', group: 'variable', label: 'בילויים', icon: '🎬', color: '#a855f7', targetMonthly: 400, order: 15, isArchived: false },
  { type: 'expense', group: 'variable', label: 'ילדים וחינוך', icon: '👶', color: '#f43f5e', targetMonthly: null, order: 16, isArchived: false },
  { type: 'expense', group: 'variable', label: 'חיות מחמד', icon: '🐕', color: '#84cc16', targetMonthly: null, order: 17, isArchived: false },
  { type: 'expense', group: 'variable', label: 'אחר', icon: '📦', color: '#71717a', targetMonthly: null, order: 99, isArchived: false },
  
  // Income
  { type: 'income', group: 'fixed', label: 'משכורת', icon: '💰', color: '#10b981', targetMonthly: null, order: 0, isArchived: false },
  { type: 'income', group: 'fixed', label: 'משכורת בן/בת זוג', icon: '💰', color: '#059669', targetMonthly: null, order: 1, isArchived: false },
  { type: 'income', group: 'variable', label: 'בונוס', icon: '🎁', color: '#22d3ee', targetMonthly: null, order: 10, isArchived: false },
  { type: 'income', group: 'variable', label: 'השקעות', icon: '📈', color: '#6366f1', targetMonthly: null, order: 11, isArchived: false },
  { type: 'income', group: 'variable', label: 'פרילנס', icon: '💻', color: '#8b5cf6', targetMonthly: null, order: 12, isArchived: false },
  { type: 'income', group: 'variable', label: 'הכנסה אחרת', icon: '📥', color: '#64748b', targetMonthly: null, order: 99, isArchived: false },
];

export const WORKSPACE_COLORS = [
  '#0c85f4', // Primary blue
  '#8b5cf6', // Purple
  '#10b981', // Green
  '#f59e0b', // Amber
  '#ef4444', // Red
  '#ec4899', // Pink
  '#06b6d4', // Cyan
  '#6366f1', // Indigo
];

export const WORKSPACE_ICONS = ['💰', '🏠', '💼', '👨‍👩‍👧‍👦', '🏢', '📊', '💳', '🎯'];
