import { useState, useCallback } from 'react';
import { Plus, Download, Upload } from 'lucide-react';
import { useTransactions, useWorkspace } from '@/hooks';
import { TransactionFilters } from '@/components/filters';
import { TransactionList, TransactionForm, type TransactionFormData } from '@/components/transactions';
import { Button, Card } from '@/components/ui';
import type { TransactionWithCategory } from '@/types';

export function TransactionsPage() {
  const { currentWorkspace } = useWorkspace();
  const {
    filteredTransactions,
    filters,
    isLoading,
    hasMore,
    setQuickFilters,
    setAdvancedFilters,
    resetFilters,
    addTransaction,
    editTransaction,
    removeTransaction,
    loadMore,
  } = useTransactions();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<TransactionWithCategory | null>(null);
  
  const currency = currentWorkspace?.currency || 'ILS';
  
  const handleAddTransaction = async (data: TransactionFormData) => {
    await addTransaction(data);
  };
  
  const handleEditTransaction = async (data: TransactionFormData) => {
    if (!editingTransaction) return;
    
    await editTransaction(editingTransaction.id, data);
    setEditingTransaction(null);
  };
  
  const handleDeleteTransaction = async (id: string) => {
    await removeTransaction(id);
  };
  
  const handleDuplicateTransaction = useCallback((transaction: TransactionWithCategory) => {
    // Open form with duplicated data
    setEditingTransaction({
      ...transaction,
      id: '', // Clear ID to create new
      date: new Date(), // Use today's date
    });
  }, []);
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold text-surface-900">
            פעולות
          </h1>
          <p className="text-surface-500 mt-1">
            נהל את ההכנסות וההוצאות שלך
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="secondary" leftIcon={<Download className="w-4 h-4" />}>
            ייצוא
          </Button>
          <Button variant="secondary" leftIcon={<Upload className="w-4 h-4" />}>
            ייבוא
          </Button>
          <Button onClick={() => setShowAddForm(true)} leftIcon={<Plus className="w-5 h-5" />}>
            הוסף פעולה
          </Button>
        </div>
      </div>
      
      {/* Filters */}
      <Card padding="md">
        <TransactionFilters
          quickFilters={filters.quick}
          advancedFilters={filters.advanced}
          onQuickFilterChange={setQuickFilters}
          onAdvancedFilterChange={setAdvancedFilters}
          onReset={resetFilters}
          transactionCount={filteredTransactions.length}
        />
      </Card>
      
      {/* Transactions List */}
      <TransactionList
        transactions={filteredTransactions}
        currency={currency}
        isLoading={isLoading}
        onEdit={setEditingTransaction}
        onDelete={handleDeleteTransaction}
        onDuplicate={handleDuplicateTransaction}
      />
      
      {/* Load More */}
      {hasMore && !isLoading && (
        <div className="text-center">
          <Button variant="secondary" onClick={loadMore}>
            טען עוד
          </Button>
        </div>
      )}
      
      {/* Add Transaction Form */}
      <TransactionForm
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        onSubmit={handleAddTransaction}
        mode="create"
      />
      
      {/* Edit Transaction Form */}
      {editingTransaction && (
        <TransactionForm
          isOpen={!!editingTransaction}
          onClose={() => setEditingTransaction(null)}
          onSubmit={editingTransaction.id ? handleEditTransaction : handleAddTransaction}
          initialData={editingTransaction}
          mode={editingTransaction.id ? 'edit' : 'create'}
        />
      )}
    </div>
  );
}
