import { useState, useMemo } from 'react';
import { Plus, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTransactions, useCategories, useWorkspace } from '@/hooks';
import { SummaryCards, ExpenseBreakdown, CategoryBreakdown } from '@/components/dashboard';
import { TransactionList } from '@/components/transactions';
import { TransactionForm, type TransactionFormData } from '@/components/transactions';
import { Button, Card } from '@/components/ui';
import { calculateMonthlyTotals, calculateCategorySummaries } from '@/lib/calculations';
import { formatMonth } from '@/utils';

export function DashboardPage() {
  const { currentWorkspace } = useWorkspace();
  const { categories } = useCategories();
  const {
    filteredTransactions,
    filters,
    isLoading,
    addTransaction,
  } = useTransactions();
  
  const [showAddForm, setShowAddForm] = useState(false);
  
  // Calculate totals
  const totals = useMemo(() => {
    return calculateMonthlyTotals(
      filteredTransactions.map((tx) => ({
        ...tx,
        category: undefined,
      })),
      categories
    );
  }, [filteredTransactions, categories]);
  
  // Calculate category summaries for expenses
  const expenseSummaries = useMemo(() => {
    const expenseTransactions = filteredTransactions.filter((tx) => tx.type === 'expense');
    return calculateCategorySummaries(expenseTransactions, categories, 'expense');
  }, [filteredTransactions, categories]);
  
  // Recent transactions (last 5)
  const recentTransactions = useMemo(() => {
    return filteredTransactions.slice(0, 5);
  }, [filteredTransactions]);
  
  const handleAddTransaction = async (data: TransactionFormData) => {
    await addTransaction(data);
  };
  
  const currency = currentWorkspace?.currency || 'ILS';
  const monthLabel = formatMonth(filters.quick.month, filters.quick.year);
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold text-surface-900">
            שלום, {currentWorkspace?.name} 👋
          </h1>
          <p className="text-surface-500 mt-1">
            סיכום {monthLabel}
          </p>
        </div>
        
        <Button onClick={() => setShowAddForm(true)} leftIcon={<Plus className="w-5 h-5" />}>
          הוסף פעולה
        </Button>
      </div>
      
      {/* Summary Cards */}
      <SummaryCards totals={totals} currency={currency} isLoading={isLoading} />
      
      {/* Expense Breakdown */}
      <ExpenseBreakdown
        fixedExpenses={totals.fixedExpenses}
        variableExpenses={totals.variableExpenses}
        currency={currency}
        isLoading={isLoading}
      />
      
      {/* Main content grid */}
      <div className="grid lg:grid-cols-5 gap-6">
        {/* Category Breakdown */}
        <div className="lg:col-span-2">
          <CategoryBreakdown
            summaries={expenseSummaries}
            currency={currency}
            title="הוצאות לפי קטגוריה"
            isLoading={isLoading}
          />
        </div>
        
        {/* Recent Transactions */}
        <div className="lg:col-span-3">
          <Card padding="md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-surface-900">פעולות אחרונות</h3>
              <Link
                to="/transactions"
                className="text-sm text-primary-600 hover:text-primary-700 font-medium flex items-center gap-1"
              >
                צפה בהכל
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
            
            <TransactionList
              transactions={recentTransactions}
              currency={currency}
              isLoading={isLoading}
              groupByDate={false}
            />
          </Card>
        </div>
      </div>
      
      {/* Quick actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <QuickActionCard
          icon="💰"
          title="הוסף הכנסה"
          onClick={() => setShowAddForm(true)}
        />
        <QuickActionCard
          icon="🛒"
          title="הוסף הוצאה"
          onClick={() => setShowAddForm(true)}
        />
        <QuickActionCard
          icon="📊"
          title="צפה בדוחות"
          to="/reports"
        />
        <QuickActionCard
          icon="⚙️"
          title="הגדרות"
          to="/settings"
        />
      </div>
      
      {/* Add Transaction Form */}
      <TransactionForm
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        onSubmit={handleAddTransaction}
      />
    </div>
  );
}

// Quick Action Card
interface QuickActionCardProps {
  icon: string;
  title: string;
  onClick?: () => void;
  to?: string;
}

function QuickActionCard({ icon, title, onClick, to }: QuickActionCardProps) {
  const content = (
    <div className="flex items-center gap-3 p-4 bg-white rounded-xl border border-surface-100 hover:border-primary-200 hover:shadow-sm transition-all cursor-pointer">
      <span className="text-2xl">{icon}</span>
      <span className="font-medium text-surface-700">{title}</span>
    </div>
  );
  
  if (to) {
    return <Link to={to}>{content}</Link>;
  }
  
  return <button onClick={onClick} className="w-full text-right">{content}</button>;
}
