import { useState } from 'react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Receipt,
  Tags,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  X,
} from 'lucide-react';
import { useAuth, useWorkspace } from '@/hooks';
import { WorkspaceSwitcher } from '@/components/workspace';
import { Avatar, Badge } from '@/components/ui';
import { cn } from '@/utils';

const navigation = [
  { name: 'סקירה כללית', href: '/', icon: LayoutDashboard },
  { name: 'פעולות', href: '/transactions', icon: Receipt },
  { name: 'קטגוריות', href: '/categories', icon: Tags },
  { name: 'דוחות', href: '/reports', icon: BarChart3 },
];

export function AppLayout() {
  const location = useLocation();
  const { user, logOut } = useAuth();
  const { currentWorkspace } = useWorkspace();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const handleLogout = async () => {
    await logOut();
  };
  
  const isPlanFree = user?.plan === 'free';
  
  return (
    <div className="min-h-screen bg-surface-50">
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-surface-900/50 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 right-0 h-full w-72 bg-white border-l border-surface-100',
          'z-50 transition-transform duration-300 ease-out',
          'lg:translate-x-0',
          isSidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-5 border-b border-surface-100">
            <div className="flex items-center justify-between">
              <Link to="/" className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-secondary-600 flex items-center justify-center text-xl text-white shadow-md">
                  💰
                </div>
                <div>
                  <h1 className="font-display font-bold text-surface-900">Budget Pro</h1>
                  <span className="text-xs text-surface-500">ניהול תקציב חכם</span>
                </div>
              </Link>
              
              <button
                onClick={() => setIsSidebarOpen(false)}
                className="p-2 rounded-lg hover:bg-surface-100 lg:hidden"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          {/* Workspace Switcher */}
          <div className="p-4 border-b border-surface-100">
            <WorkspaceSwitcher />
          </div>
          
          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href;
              
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setIsSidebarOpen(false)}
                  className={cn(
                    'flex items-center gap-3 px-4 py-3 rounded-xl transition-all',
                    isActive
                      ? 'bg-primary-50 text-primary-600 font-medium'
                      : 'text-surface-600 hover:bg-surface-50 hover:text-surface-900'
                  )}
                >
                  <Icon className={cn('w-5 h-5', isActive && 'text-primary-500')} />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>
          
          {/* Upgrade prompt */}
          {isPlanFree && (
            <div className="p-4">
              <div className="p-4 bg-gradient-to-r from-primary-50 to-secondary-50 rounded-xl border border-primary-100">
                <h4 className="font-semibold text-surface-900 mb-1">שדרג ל-Pro</h4>
                <p className="text-sm text-surface-600 mb-3">
                  קבל גישה לדוחות מתקדמים וworkspaces נוספים
                </p>
                <Link
                  to="/settings/billing"
                  className="text-sm font-semibold text-primary-600 hover:text-primary-700"
                >
                  שדרג עכשיו →
                </Link>
              </div>
            </div>
          )}
          
          {/* User section */}
          <div className="p-4 border-t border-surface-100">
            <Link
              to="/settings"
              className="flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-surface-50 transition-colors"
            >
              <Avatar
                src={user?.photoURL}
                name={user?.displayName}
                size="md"
              />
              <div className="flex-1 min-w-0">
                <div className="font-medium text-surface-900 truncate">
                  {user?.displayName || 'משתמש'}
                </div>
                <div className="text-xs text-surface-500 truncate">{user?.email}</div>
              </div>
              <Settings className="w-5 h-5 text-surface-400" />
            </Link>
            
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 mt-2 rounded-xl text-surface-600 hover:bg-surface-50 hover:text-danger-600 transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span>התנתקות</span>
            </button>
          </div>
        </div>
      </aside>
      
      {/* Main content */}
      <div className="lg:pr-72">
        {/* Top bar (mobile) */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-lg border-b border-surface-100 lg:hidden">
          <div className="flex items-center justify-between px-4 py-3">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 rounded-lg hover:bg-surface-100"
            >
              <Menu className="w-6 h-6" />
            </button>
            
            <div className="flex items-center gap-2">
              <span className="text-lg">{currentWorkspace?.icon}</span>
              <span className="font-semibold text-surface-900">
                {currentWorkspace?.name}
              </span>
            </div>
            
            <Avatar
              src={user?.photoURL}
              name={user?.displayName}
              size="sm"
            />
          </div>
        </header>
        
        {/* Page content */}
        <main className="p-4 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
