import { TrendingUp, TrendingDown, Wallet, PiggyBank, Building2, ShoppingCart } from 'lucide-react';
import { Card, Skeleton } from '@/components/ui';
import { cn, formatCurrency, formatPercent } from '@/utils';
import type { MonthlyTotals, Currency } from '@/types';

interface SummaryCardsProps {
  totals: MonthlyTotals;
  currency: Currency;
  previousTotals?: MonthlyTotals;
  isLoading?: boolean;
}

export function SummaryCards({ totals, currency, previousTotals, isLoading }: SummaryCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} padding="md">
            <Skeleton className="h-4 w-20 mb-3" />
            <Skeleton className="h-8 w-28 mb-2" />
            <Skeleton className="h-4 w-16" />
          </Card>
        ))}
      </div>
    );
  }
  
  const savingsRate = totals.income > 0
    ? ((totals.income - totals.expense) / totals.income) * 100
    : 0;
  
  const getChange = (current: number, previous?: number) => {
    if (!previous || previous === 0) return null;
    return ((current - previous) / previous) * 100;
  };
  
  const cards = [
    {
      title: 'הכנסות',
      value: totals.income,
      icon: TrendingUp,
      color: 'success',
      change: getChange(totals.income, previousTotals?.income),
    },
    {
      title: 'הוצאות',
      value: totals.expense,
      icon: TrendingDown,
      color: 'danger',
      change: getChange(totals.expense, previousTotals?.expense),
    },
    {
      title: 'יתרה',
      value: totals.balance,
      icon: Wallet,
      color: totals.balance >= 0 ? 'primary' : 'danger',
      change: getChange(totals.balance, previousTotals?.balance),
    },
    {
      title: 'שיעור חיסכון',
      value: savingsRate,
      icon: PiggyBank,
      color: savingsRate >= 20 ? 'success' : savingsRate >= 10 ? 'warning' : 'danger',
      isPercent: true,
    },
  ];
  
  const colorClasses = {
    success: {
      bg: 'bg-success-50',
      text: 'text-success-600',
      icon: 'text-success-500',
    },
    danger: {
      bg: 'bg-danger-50',
      text: 'text-danger-600',
      icon: 'text-danger-500',
    },
    warning: {
      bg: 'bg-warning-50',
      text: 'text-warning-600',
      icon: 'text-warning-500',
    },
    primary: {
      bg: 'bg-primary-50',
      text: 'text-primary-600',
      icon: 'text-primary-500',
    },
  };
  
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card) => {
        const colors = colorClasses[card.color as keyof typeof colorClasses];
        const Icon = card.icon;
        
        return (
          <Card key={card.title} padding="md" className="relative overflow-hidden">
            {/* Background decoration */}
            <div className={cn(
              'absolute -left-6 -bottom-6 w-24 h-24 rounded-full opacity-50',
              colors.bg
            )} />
            
            <div className="relative">
              {/* Header */}
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-surface-500">{card.title}</span>
                <div className={cn('p-2 rounded-lg', colors.bg)}>
                  <Icon className={cn('w-4 h-4', colors.icon)} />
                </div>
              </div>
              
              {/* Value */}
              <div className={cn('text-2xl font-bold font-display', colors.text)}>
                {card.isPercent ? (
                  formatPercent(card.value, 1)
                ) : (
                  <span className="tabular-nums" dir="ltr">
                    {card.value < 0 ? '-' : ''}
                    {formatCurrency(Math.abs(card.value), currency)}
                  </span>
                )}
              </div>
              
              {/* Change indicator */}
              {card.change !== undefined && card.change !== null && (
                <div className={cn(
                  'mt-2 text-sm flex items-center gap-1',
                  card.change > 0 ? 'text-success-600' : card.change < 0 ? 'text-danger-600' : 'text-surface-500'
                )}>
                  {card.change > 0 ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : card.change < 0 ? (
                    <TrendingDown className="w-3 h-3" />
                  ) : null}
                  <span>
                    {card.change > 0 ? '+' : ''}
                    {formatPercent(card.change, 1)} מחודש קודם
                  </span>
                </div>
              )}
            </div>
          </Card>
        );
      })}
    </div>
  );
}

// ============================================================
// EXPENSE BREAKDOWN MINI CARDS
// ============================================================

interface ExpenseBreakdownProps {
  fixedExpenses: number;
  variableExpenses: number;
  currency: Currency;
  isLoading?: boolean;
}

export function ExpenseBreakdown({ fixedExpenses, variableExpenses, currency, isLoading }: ExpenseBreakdownProps) {
  const total = fixedExpenses + variableExpenses;
  const fixedPercent = total > 0 ? (fixedExpenses / total) * 100 : 0;
  const variablePercent = total > 0 ? (variableExpenses / total) * 100 : 0;
  
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-4">
        {[...Array(2)].map((_, i) => (
          <Card key={i} padding="sm">
            <Skeleton className="h-4 w-16 mb-2" />
            <Skeleton className="h-6 w-24" />
          </Card>
        ))}
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-2 gap-4">
      <Card padding="sm" className="border-r-4 border-r-secondary-500">
        <div className="flex items-center gap-2 text-surface-500 text-sm mb-1">
          <Building2 className="w-4 h-4" />
          <span>הוצאות קבועות</span>
        </div>
        <div className="font-semibold text-surface-900 tabular-nums" dir="ltr">
          {formatCurrency(fixedExpenses, currency)}
        </div>
        <div className="text-xs text-surface-400 mt-1">
          {formatPercent(fixedPercent, 0)} מסך ההוצאות
        </div>
      </Card>
      
      <Card padding="sm" className="border-r-4 border-r-warning-500">
        <div className="flex items-center gap-2 text-surface-500 text-sm mb-1">
          <ShoppingCart className="w-4 h-4" />
          <span>הוצאות משתנות</span>
        </div>
        <div className="font-semibold text-surface-900 tabular-nums" dir="ltr">
          {formatCurrency(variableExpenses, currency)}
        </div>
        <div className="text-xs text-surface-400 mt-1">
          {formatPercent(variablePercent, 0)} מסך ההוצאות
        </div>
      </Card>
    </div>
  );
}
