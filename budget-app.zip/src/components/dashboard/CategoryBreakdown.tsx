import { useMemo } from 'react';
import { Card, Skeleton, Badge } from '@/components/ui';
import { cn, formatCurrency, formatPercent, hexToRgba } from '@/utils';
import type { CategorySummary, Currency } from '@/types';

interface CategoryBreakdownProps {
  summaries: CategorySummary[];
  currency: Currency;
  title?: string;
  isLoading?: boolean;
  maxItems?: number;
}

export function CategoryBreakdown({
  summaries,
  currency,
  title = 'התפלגות לפי קטגוריה',
  isLoading,
  maxItems = 8,
}: CategoryBreakdownProps) {
  const displaySummaries = useMemo(() => {
    return summaries.slice(0, maxItems);
  }, [summaries, maxItems]);
  
  const totalAmount = useMemo(() => {
    return summaries.reduce((sum, s) => sum + s.total, 0);
  }, [summaries]);
  
  if (isLoading) {
    return (
      <Card padding="md">
        <Skeleton className="h-5 w-32 mb-4" />
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center gap-3">
              <Skeleton className="w-8 h-8 rounded-lg" />
              <div className="flex-1">
                <Skeleton className="h-4 w-24 mb-1" />
                <Skeleton className="h-2 w-full rounded-full" />
              </div>
              <Skeleton className="h-5 w-16" />
            </div>
          ))}
        </div>
      </Card>
    );
  }
  
  if (summaries.length === 0) {
    return (
      <Card padding="md">
        <h3 className="font-semibold text-surface-900 mb-4">{title}</h3>
        <p className="text-center text-surface-500 py-8">אין נתונים להצגה</p>
      </Card>
    );
  }
  
  return (
    <Card padding="md">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-surface-900">{title}</h3>
        <span className="text-sm text-surface-500">
          סה"כ: {formatCurrency(totalAmount, currency)}
        </span>
      </div>
      
      <div className="space-y-4">
        {displaySummaries.map((summary) => (
          <CategoryRow
            key={summary.categoryId}
            summary={summary}
            currency={currency}
            totalAmount={totalAmount}
          />
        ))}
        
        {summaries.length > maxItems && (
          <button className="w-full text-center text-sm text-primary-600 hover:text-primary-700 font-medium py-2">
            ועוד {summaries.length - maxItems} קטגוריות...
          </button>
        )}
      </div>
    </Card>
  );
}

// ============================================================
// CATEGORY ROW
// ============================================================

interface CategoryRowProps {
  summary: CategorySummary;
  currency: Currency;
  totalAmount: number;
}

function CategoryRow({ summary, currency, totalAmount }: CategoryRowProps) {
  const { category, total, count, percentOfTotal, targetMonthly, percentOfTarget, isOverBudget } = summary;
  
  return (
    <div className="group">
      <div className="flex items-center gap-3">
        {/* Icon */}
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center text-lg shrink-0"
          style={{ backgroundColor: hexToRgba(category.color, 0.12) }}
        >
          {category.icon}
        </div>
        
        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-surface-900 truncate">{category.label}</span>
            {isOverBudget && (
              <Badge variant="danger" size="sm">חריגה</Badge>
            )}
          </div>
          
          {/* Progress bar */}
          <div className="mt-1.5 h-2 bg-surface-100 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${Math.min(percentOfTotal, 100)}%`,
                backgroundColor: category.color,
              }}
            />
          </div>
        </div>
        
        {/* Amount */}
        <div className="text-left shrink-0">
          <div className="font-semibold text-surface-900 tabular-nums" dir="ltr">
            {formatCurrency(total, currency)}
          </div>
          <div className="text-xs text-surface-500">
            {formatPercent(percentOfTotal, 1)}
          </div>
        </div>
      </div>
      
      {/* Budget progress (if target exists) */}
      {targetMonthly !== null && (
        <div className="mt-2 pr-12">
          <div className="flex items-center justify-between text-xs text-surface-500 mb-1">
            <span>
              תקציב: {formatCurrency(targetMonthly, currency)}
            </span>
            <span className={isOverBudget ? 'text-danger-600 font-medium' : ''}>
              {formatPercent(percentOfTarget || 0, 0)}
            </span>
          </div>
          <div className="h-1.5 bg-surface-100 rounded-full overflow-hidden">
            <div
              className={cn(
                'h-full rounded-full transition-all duration-500',
                isOverBudget ? 'bg-danger-500' : 'bg-success-500'
              )}
              style={{ width: `${Math.min(percentOfTarget || 0, 100)}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// COMPACT VERSION
// ============================================================

interface CategoryBreakdownCompactProps {
  summaries: CategorySummary[];
  currency: Currency;
}

export function CategoryBreakdownCompact({ summaries, currency }: CategoryBreakdownCompactProps) {
  const topCategories = summaries.slice(0, 5);
  
  return (
    <div className="flex flex-wrap gap-2">
      {topCategories.map((summary) => (
        <div
          key={summary.categoryId}
          className="flex items-center gap-2 px-3 py-1.5 bg-surface-50 rounded-lg"
        >
          <span>{summary.category.icon}</span>
          <span className="text-sm font-medium text-surface-700">
            {summary.category.label}
          </span>
          <span className="text-sm text-surface-500 tabular-nums" dir="ltr">
            {formatCurrency(summary.total, currency)}
          </span>
        </div>
      ))}
    </div>
  );
}
