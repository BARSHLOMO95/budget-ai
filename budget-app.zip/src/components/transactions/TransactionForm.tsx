import { useState, useEffect } from 'react';
import { Calendar, Tag, FileText, Hash } from 'lucide-react';
import { Button, Input, Select, Badge } from '@/components/ui';
import { Modal } from '@/components/ui/Modal';
import { useCategoryOptions, useWorkspace } from '@/hooks';
import { cn, formatCurrency } from '@/utils';
import type { Transaction, TransactionType, CategoryGroup } from '@/types';

interface TransactionFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: TransactionFormData) => Promise<void>;
  initialData?: Partial<Transaction>;
  mode?: 'create' | 'edit';
}

export interface TransactionFormData {
  type: TransactionType;
  amount: number;
  categoryId: string;
  description: string;
  date: Date;
  isRecurring?: boolean;
  tags?: string[];
  notes?: string;
}

export function TransactionForm({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  mode = 'create',
}: TransactionFormProps) {
  const { currentWorkspace } = useWorkspace();
  
  const [type, setType] = useState<TransactionType>(initialData?.type || 'expense');
  const [amount, setAmount] = useState(initialData?.amount?.toString() || '');
  const [categoryId, setCategoryId] = useState(initialData?.categoryId || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [date, setDate] = useState(
    initialData?.date
      ? new Date(initialData.date).toISOString().split('T')[0]
      : new Date().toISOString().split('T')[0]
  );
  const [notes, setNotes] = useState(initialData?.notes || '');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>(initialData?.tags || []);
  const [isRecurring, setIsRecurring] = useState(initialData?.isRecurring || false);
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const { groupedOptions, isLoading: categoriesLoading } = useCategoryOptions(type);
  
  // Reset category when type changes
  useEffect(() => {
    if (mode === 'create') {
      setCategoryId('');
    }
  }, [type, mode]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const amountNum = parseFloat(amount.replace(/,/g, ''));
    
    if (!amountNum || amountNum <= 0) {
      setError('נא להזין סכום תקין');
      return;
    }
    
    if (!categoryId) {
      setError('נא לבחור קטגוריה');
      return;
    }
    
    if (!description.trim()) {
      setError('נא להזין תיאור');
      return;
    }
    
    setIsLoading(true);
    
    try {
      await onSubmit({
        type,
        amount: amountNum,
        categoryId,
        description: description.trim(),
        date: new Date(date),
        isRecurring,
        tags,
        notes: notes.trim() || undefined,
      });
      
      // Reset form
      if (mode === 'create') {
        setAmount('');
        setDescription('');
        setNotes('');
        setTags([]);
        setCategoryId('');
      }
      
      onClose();
    } catch (err) {
      setError((err as Error).message || 'אירעה שגיאה');
    } finally {
      setIsLoading(false);
    }
  };
  
  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };
  
  const removeTag = (tag: string) => {
    setTags(tags.filter((t) => t !== tag));
  };
  
  const formatAmountInput = (value: string) => {
    // Remove non-numeric characters except decimal point
    const cleaned = value.replace(/[^\d.]/g, '');
    setAmount(cleaned);
  };
  
  const currency = currentWorkspace?.currency || 'ILS';
  
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={mode === 'create' ? 'הוספת פעולה חדשה' : 'עריכת פעולה'}
      size="md"
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        {error && (
          <div className="p-3 rounded-xl bg-danger-50 border border-danger-200 text-danger-700 text-sm">
            {error}
          </div>
        )}
        
        {/* Transaction Type Toggle */}
        <div className="flex p-1 bg-surface-100 rounded-xl">
          <button
            type="button"
            onClick={() => setType('expense')}
            className={cn(
              'flex-1 py-2.5 px-4 rounded-lg font-medium transition-all',
              type === 'expense'
                ? 'bg-danger-500 text-white shadow-sm'
                : 'text-surface-600 hover:text-surface-900'
            )}
          >
            הוצאה
          </button>
          <button
            type="button"
            onClick={() => setType('income')}
            className={cn(
              'flex-1 py-2.5 px-4 rounded-lg font-medium transition-all',
              type === 'income'
                ? 'bg-success-500 text-white shadow-sm'
                : 'text-surface-600 hover:text-surface-900'
            )}
          >
            הכנסה
          </button>
        </div>
        
        {/* Amount */}
        <div>
          <label className="label">סכום</label>
          <div className="relative">
            <input
              type="text"
              inputMode="decimal"
              value={amount}
              onChange={(e) => formatAmountInput(e.target.value)}
              placeholder="0.00"
              className={cn(
                'input text-2xl font-mono font-semibold text-center py-4',
                type === 'expense' ? 'text-danger-600' : 'text-success-600'
              )}
              dir="ltr"
              required
            />
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-surface-400 text-lg">
              {currency === 'ILS' ? '₪' : currency === 'USD' ? '$' : '€'}
            </span>
          </div>
          {amount && (
            <p className="text-sm text-surface-500 mt-1 text-center">
              {formatCurrency(parseFloat(amount.replace(/,/g, '')) || 0, currency)}
            </p>
          )}
        </div>
        
        {/* Category */}
        <div>
          <label className="label">קטגוריה</label>
          {categoriesLoading ? (
            <div className="h-11 bg-surface-100 rounded-xl animate-pulse" />
          ) : (
            <div className="space-y-3">
              {/* Fixed categories */}
              {groupedOptions.fixed.length > 0 && (
                <div>
                  <div className="text-xs text-surface-500 mb-2">קבועות</div>
                  <div className="flex flex-wrap gap-2">
                    {groupedOptions.fixed.map((cat) => (
                      <button
                        key={cat.value}
                        type="button"
                        onClick={() => setCategoryId(cat.value)}
                        className={cn(
                          'px-3 py-1.5 rounded-lg text-sm font-medium transition-all',
                          'flex items-center gap-1.5',
                          categoryId === cat.value
                            ? 'ring-2 ring-offset-2'
                            : 'hover:bg-surface-100'
                        )}
                        style={{
                          backgroundColor:
                            categoryId === cat.value ? cat.color + '20' : undefined,
                          color: categoryId === cat.value ? cat.color : undefined,
                          ringColor: categoryId === cat.value ? cat.color : undefined,
                        }}
                      >
                        <span>{cat.icon}</span>
                        <span>{cat.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Variable categories */}
              {groupedOptions.variable.length > 0 && (
                <div>
                  <div className="text-xs text-surface-500 mb-2">משתנות</div>
                  <div className="flex flex-wrap gap-2">
                    {groupedOptions.variable.map((cat) => (
                      <button
                        key={cat.value}
                        type="button"
                        onClick={() => setCategoryId(cat.value)}
                        className={cn(
                          'px-3 py-1.5 rounded-lg text-sm font-medium transition-all',
                          'flex items-center gap-1.5',
                          categoryId === cat.value
                            ? 'ring-2 ring-offset-2'
                            : 'hover:bg-surface-100'
                        )}
                        style={{
                          backgroundColor:
                            categoryId === cat.value ? cat.color + '20' : undefined,
                          color: categoryId === cat.value ? cat.color : undefined,
                          ringColor: categoryId === cat.value ? cat.color : undefined,
                        }}
                      >
                        <span>{cat.icon}</span>
                        <span>{cat.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Description */}
        <Input
          label="תיאור"
          placeholder={type === 'expense' ? 'למשל: קניות בסופר' : 'למשל: משכורת חודשית'}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          leftIcon={<FileText className="w-5 h-5" />}
          required
        />
        
        {/* Date */}
        <div>
          <label className="label">תאריך</label>
          <div className="relative">
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="input"
              required
            />
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-surface-400 pointer-events-none" />
          </div>
        </div>
        
        {/* Tags */}
        <div>
          <label className="label">תגיות (אופציונלי)</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addTag();
                }
              }}
              placeholder="הוסף תגית..."
              className="input flex-1"
            />
            <Button type="button" variant="secondary" onClick={addTag}>
              הוסף
            </Button>
          </div>
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {tags.map((tag) => (
                <Badge key={tag} variant="primary">
                  <span>{tag}</span>
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="mr-1 hover:text-danger-600"
                  >
                    ×
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>
        
        {/* Notes */}
        <div>
          <label className="label">הערות (אופציונלי)</label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="הערות נוספות..."
            className="input min-h-[80px] resize-none"
            rows={3}
          />
        </div>
        
        {/* Recurring toggle */}
        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={isRecurring}
            onChange={(e) => setIsRecurring(e.target.checked)}
            className="w-5 h-5 rounded border-surface-300 text-primary-600 focus:ring-primary-500"
          />
          <span className="text-surface-700">פעולה חוזרת (חודשית)</span>
        </label>
        
        {/* Actions */}
        <div className="flex gap-3 justify-end pt-2 border-t border-surface-100">
          <Button type="button" variant="secondary" onClick={onClose}>
            ביטול
          </Button>
          <Button type="submit" isLoading={isLoading}>
            {mode === 'create' ? 'הוספה' : 'שמירה'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
