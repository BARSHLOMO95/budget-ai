import { useState, useMemo } from 'react';
import { MoreVertical, Edit2, Trash2, Copy, Tag } from 'lucide-react';
import { cn, formatCurrency, formatDate, formatDateRelative, groupBy, hexToRgba } from '@/utils';
import { Badge, EmptyState, Skeleton, Card } from '@/components/ui';
import { ConfirmDialog } from '@/components/ui/Modal';
import type { TransactionWithCategory, Currency } from '@/types';

interface TransactionListProps {
  transactions: TransactionWithCategory[];
  currency: Currency;
  isLoading?: boolean;
  onEdit?: (transaction: TransactionWithCategory) => void;
  onDelete?: (transactionId: string) => void;
  onDuplicate?: (transaction: TransactionWithCategory) => void;
  groupByDate?: boolean;
}

export function TransactionList({
  transactions,
  currency,
  isLoading,
  onEdit,
  onDelete,
  onDuplicate,
  groupByDate = true,
}: TransactionListProps) {
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  
  // Group transactions by date
  const groupedTransactions = useMemo(() => {
    if (!groupByDate) {
      return { all: transactions };
    }
    
    return groupBy(transactions, (tx) => {
      const date = new Date(tx.date);
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(
        date.getDate()
      ).padStart(2, '0')}`;
    });
  }, [transactions, groupByDate]);
  
  const handleDelete = () => {
    if (deleteId && onDelete) {
      onDelete(deleteId);
      setDeleteId(null);
    }
  };
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <TransactionSkeleton key={i} />
        ))}
      </div>
    );
  }
  
  if (transactions.length === 0) {
    return (
      <EmptyState
        icon={<span className="text-3xl">📭</span>}
        title="אין פעולות עדיין"
        description="הוסף את הפעולה הראשונה שלך כדי להתחיל לעקוב אחרי התקציב"
      />
    );
  }
  
  const dateKeys = Object.keys(groupedTransactions).sort((a, b) => b.localeCompare(a));
  
  return (
    <>
      <div className="space-y-6">
        {dateKeys.map((dateKey) => {
          const dayTransactions = groupedTransactions[dateKey];
          const dayTotal = dayTransactions.reduce(
            (acc, tx) => ({
              income: acc.income + (tx.type === 'income' ? tx.amount : 0),
              expense: acc.expense + (tx.type === 'expense' ? tx.amount : 0),
            }),
            { income: 0, expense: 0 }
          );
          
          return (
            <div key={dateKey}>
              {/* Date header */}
              {groupByDate && dateKey !== 'all' && (
                <div className="flex items-center justify-between mb-3 px-1">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-surface-700">
                      {formatDateRelative(new Date(dateKey))}
                    </span>
                    <span className="text-xs text-surface-400">
                      {formatDate(new Date(dateKey), 'EEEE, d בMMMM')}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    {dayTotal.income > 0 && (
                      <span className="text-success-600 font-medium">
                        +{formatCurrency(dayTotal.income, currency)}
                      </span>
                    )}
                    {dayTotal.expense > 0 && (
                      <span className="text-danger-600 font-medium">
                        -{formatCurrency(dayTotal.expense, currency)}
                      </span>
                    )}
                  </div>
                </div>
              )}
              
              {/* Transactions */}
              <div className="space-y-2">
                {dayTransactions.map((tx) => (
                  <TransactionItem
                    key={tx.id}
                    transaction={tx}
                    currency={currency}
                    isMenuOpen={openMenuId === tx.id}
                    onMenuToggle={() =>
                      setOpenMenuId(openMenuId === tx.id ? null : tx.id)
                    }
                    onEdit={onEdit ? () => onEdit(tx) : undefined}
                    onDelete={onDelete ? () => setDeleteId(tx.id) : undefined}
                    onDuplicate={onDuplicate ? () => onDuplicate(tx) : undefined}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Delete confirmation */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="מחיקת פעולה"
        message="האם אתה בטוח שברצונך למחוק פעולה זו? פעולה זו אינה ניתנת לביטול."
        confirmText="מחק"
        variant="danger"
      />
    </>
  );
}

// ============================================================
// TRANSACTION ITEM
// ============================================================

interface TransactionItemProps {
  transaction: TransactionWithCategory;
  currency: Currency;
  isMenuOpen: boolean;
  onMenuToggle: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  onDuplicate?: () => void;
}

function TransactionItem({
  transaction,
  currency,
  isMenuOpen,
  onMenuToggle,
  onEdit,
  onDelete,
  onDuplicate,
}: TransactionItemProps) {
  const category = transaction.category;
  
  return (
    <div
      className={cn(
        'group relative bg-white rounded-xl border border-surface-100 p-4',
        'hover:border-surface-200 hover:shadow-sm transition-all'
      )}
    >
      <div className="flex items-center gap-4">
        {/* Category Icon */}
        <div
          className="w-11 h-11 rounded-xl flex items-center justify-center text-lg shrink-0"
          style={{
            backgroundColor: category ? hexToRgba(category.color, 0.12) : '#f4f4f5',
          }}
        >
          {category?.icon || '📦'}
        </div>
        
        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-surface-900 truncate">
              {transaction.description}
            </span>
            {transaction.isRecurring && (
              <Badge variant="primary" size="sm">
                חוזר
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <span
              className="text-sm"
              style={{ color: category?.color || '#71717a' }}
            >
              {category?.label || 'ללא קטגוריה'}
            </span>
            {transaction.tags.length > 0 && (
              <>
                <span className="text-surface-300">•</span>
                <div className="flex items-center gap-1 text-xs text-surface-500">
                  <Tag className="w-3 h-3" />
                  <span>{transaction.tags.join(', ')}</span>
                </div>
              </>
            )}
          </div>
        </div>
        
        {/* Amount */}
        <div
          className={cn(
            'font-mono font-semibold text-lg tabular-nums',
            transaction.type === 'income' ? 'text-success-600' : 'text-surface-900'
          )}
          dir="ltr"
        >
          {transaction.type === 'income' ? '+' : '-'}
          {formatCurrency(transaction.amount, currency)}
        </div>
        
        {/* Actions menu */}
        {(onEdit || onDelete || onDuplicate) && (
          <div className="relative">
            <button
              onClick={onMenuToggle}
              className={cn(
                'p-2 rounded-lg transition-colors',
                'opacity-0 group-hover:opacity-100',
                isMenuOpen ? 'bg-surface-100 opacity-100' : 'hover:bg-surface-100'
              )}
            >
              <MoreVertical className="w-5 h-5 text-surface-400" />
            </button>
            
            {isMenuOpen && (
              <div className="absolute left-0 top-full mt-1 w-40 bg-white rounded-xl shadow-elevated border border-surface-100 py-1 z-10 animate-scale-in">
                {onEdit && (
                  <button
                    onClick={() => {
                      onMenuToggle();
                      onEdit();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 hover:bg-surface-50 text-surface-700"
                  >
                    <Edit2 className="w-4 h-4" />
                    <span>עריכה</span>
                  </button>
                )}
                {onDuplicate && (
                  <button
                    onClick={() => {
                      onMenuToggle();
                      onDuplicate();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 hover:bg-surface-50 text-surface-700"
                  >
                    <Copy className="w-4 h-4" />
                    <span>שכפול</span>
                  </button>
                )}
                {onDelete && (
                  <button
                    onClick={() => {
                      onMenuToggle();
                      onDelete();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 hover:bg-danger-50 text-danger-600"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>מחיקה</span>
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Notes */}
      {transaction.notes && (
        <p className="mt-2 text-sm text-surface-500 pr-15">{transaction.notes}</p>
      )}
    </div>
  );
}

// ============================================================
// SKELETON
// ============================================================

function TransactionSkeleton() {
  return (
    <div className="bg-white rounded-xl border border-surface-100 p-4">
      <div className="flex items-center gap-4">
        <Skeleton variant="rectangular" className="w-11 h-11 rounded-xl" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-3 w-1/4" />
        </div>
        <Skeleton className="h-6 w-20" />
      </div>
    </div>
  );
}
