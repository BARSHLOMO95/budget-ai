import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Plus, Settings, Home, Briefcase, Check, Users } from 'lucide-react';
import { useWorkspace, useAuth } from '@/hooks';
import { cn, hexToRgba } from '@/utils';
import type { Workspace, WorkspaceType } from '@/types';

export function WorkspaceSwitcher() {
  const { workspaces, currentWorkspace, switchWorkspace } = useWorkspace();
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  const handleSelect = async (workspace: Workspace) => {
    await switchWorkspace(workspace.id);
    setIsOpen(false);
  };
  
  if (!currentWorkspace) {
    return (
      <div className="h-10 w-48 rounded-xl bg-surface-100 animate-pulse" />
    );
  }
  
  const canCreateMore = () => {
    const limits: Record<string, number> = {
      free: 1,
      pro: 3,
      pro_business: 10,
    };
    return workspaces.length < (limits[user?.plan || 'free'] || 1);
  };
  
  const canCreateBusiness = user?.plan === 'pro_business';
  
  return (
    <>
      <div className="relative" ref={dropdownRef}>
        {/* Trigger Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            'flex items-center gap-3 px-3 py-2 rounded-xl',
            'hover:bg-surface-100 transition-colors',
            'min-w-[200px]',
            isOpen && 'bg-surface-100'
          )}
        >
          {/* Workspace Icon */}
          <div
            className="w-9 h-9 rounded-lg flex items-center justify-center text-lg"
            style={{ backgroundColor: hexToRgba(currentWorkspace.color, 0.15) }}
          >
            {currentWorkspace.icon}
          </div>
          
          {/* Workspace Info */}
          <div className="flex-1 text-right min-w-0">
            <div className="font-medium text-surface-900 truncate">
              {currentWorkspace.name}
            </div>
            <div className="text-xs text-surface-500 flex items-center gap-1">
              {currentWorkspace.type === 'business' ? (
                <>
                  <Briefcase className="w-3 h-3" />
                  <span>עסקי</span>
                </>
              ) : (
                <>
                  <Home className="w-3 h-3" />
                  <span>אישי</span>
                </>
              )}
            </div>
          </div>
          
          {/* Chevron */}
          <ChevronDown
            className={cn(
              'w-5 h-5 text-surface-400 transition-transform',
              isOpen && 'rotate-180'
            )}
          />
        </button>
        
        {/* Dropdown */}
        {isOpen && (
          <div className="absolute top-full right-0 mt-2 w-72 bg-white rounded-2xl shadow-elevated border border-surface-100 overflow-hidden z-50 animate-scale-in">
            {/* Workspaces List */}
            <div className="p-2">
              <div className="text-xs font-medium text-surface-400 px-3 py-2">
                ה-Workspaces שלך
              </div>
              
              {workspaces.map((workspace) => (
                <button
                  key={workspace.id}
                  onClick={() => handleSelect(workspace)}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl',
                    'hover:bg-surface-50 transition-colors',
                    workspace.id === currentWorkspace.id && 'bg-primary-50'
                  )}
                >
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center text-lg shrink-0"
                    style={{ backgroundColor: hexToRgba(workspace.color, 0.15) }}
                  >
                    {workspace.icon}
                  </div>
                  
                  <div className="flex-1 text-right min-w-0">
                    <div className="font-medium text-surface-900 truncate">
                      {workspace.name}
                    </div>
                    <div className="text-xs text-surface-500 flex items-center gap-1">
                      {workspace.type === 'business' ? (
                        <>
                          <Briefcase className="w-3 h-3" />
                          <span>עסקי</span>
                        </>
                      ) : (
                        <>
                          <Home className="w-3 h-3" />
                          <span>אישי</span>
                        </>
                      )}
                    </div>
                  </div>
                  
                  {workspace.id === currentWorkspace.id && (
                    <Check className="w-5 h-5 text-primary-600 shrink-0" />
                  )}
                </button>
              ))}
            </div>
            
            {/* Divider */}
            <div className="h-px bg-surface-100" />
            
            {/* Actions */}
            <div className="p-2">
              {canCreateMore() && (
                <button
                  onClick={() => {
                    setIsOpen(false);
                    setShowCreateModal(true);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-surface-50 transition-colors text-surface-600"
                >
                  <div className="w-9 h-9 rounded-lg bg-surface-100 flex items-center justify-center">
                    <Plus className="w-5 h-5" />
                  </div>
                  <span className="font-medium">יצירת Workspace חדש</span>
                </button>
              )}
              
              <button
                onClick={() => setIsOpen(false)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-surface-50 transition-colors text-surface-600"
              >
                <div className="w-9 h-9 rounded-lg bg-surface-100 flex items-center justify-center">
                  <Users className="w-5 h-5" />
                </div>
                <span className="font-medium">ניהול חברים</span>
              </button>
              
              <button
                onClick={() => setIsOpen(false)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-surface-50 transition-colors text-surface-600"
              >
                <div className="w-9 h-9 rounded-lg bg-surface-100 flex items-center justify-center">
                  <Settings className="w-5 h-5" />
                </div>
                <span className="font-medium">הגדרות Workspace</span>
              </button>
            </div>
            
            {/* Upgrade prompt for free users */}
            {!canCreateMore() && user?.plan === 'free' && (
              <>
                <div className="h-px bg-surface-100" />
                <div className="p-4 bg-gradient-to-r from-primary-50 to-secondary-50">
                  <p className="text-sm text-surface-700 mb-2">
                    שדרג ל-Pro כדי ליצור workspaces נוספים
                  </p>
                  <button className="text-sm font-semibold text-primary-600 hover:text-primary-700">
                    שדרג עכשיו →
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
      
      {/* Create Workspace Modal */}
      {showCreateModal && (
        <CreateWorkspaceModal
          isOpen={showCreateModal}
          onClose={() => setShowCreateModal(false)}
          canCreateBusiness={canCreateBusiness}
        />
      )}
    </>
  );
}

// ============================================================
// CREATE WORKSPACE MODAL
// ============================================================

import { Modal } from '@/components/ui/Modal';
import { Button, Input } from '@/components/ui';
import { WORKSPACE_COLORS, WORKSPACE_ICONS } from '@/types';

interface CreateWorkspaceModalProps {
  isOpen: boolean;
  onClose: () => void;
  canCreateBusiness: boolean;
}

function CreateWorkspaceModal({ isOpen, onClose, canCreateBusiness }: CreateWorkspaceModalProps) {
  const { createNewWorkspace } = useWorkspace();
  
  const [name, setName] = useState('');
  const [type, setType] = useState<WorkspaceType>('personal');
  const [icon, setIcon] = useState('💰');
  const [color, setColor] = useState(WORKSPACE_COLORS[0]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      setError('נא להזין שם ל-Workspace');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      await createNewWorkspace({
        name: name.trim(),
        type,
        icon,
        color,
      });
      onClose();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Modal isOpen={isOpen} onClose={onClose} title="יצירת Workspace חדש" size="md">
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="p-3 rounded-xl bg-danger-50 border border-danger-200 text-danger-700 text-sm">
            {error}
          </div>
        )}
        
        {/* Workspace Type */}
        <div>
          <label className="label">סוג Workspace</label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setType('personal')}
              className={cn(
                'p-4 rounded-xl border-2 transition-all text-right',
                type === 'personal'
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-surface-200 hover:border-surface-300'
              )}
            >
              <Home className="w-6 h-6 mb-2 text-primary-600" />
              <div className="font-semibold text-surface-900">אישי / משפחתי</div>
              <div className="text-sm text-surface-500">תקציב הבית והמשפחה</div>
            </button>
            
            <button
              type="button"
              onClick={() => canCreateBusiness && setType('business')}
              disabled={!canCreateBusiness}
              className={cn(
                'p-4 rounded-xl border-2 transition-all text-right',
                type === 'business'
                  ? 'border-secondary-500 bg-secondary-50'
                  : 'border-surface-200 hover:border-surface-300',
                !canCreateBusiness && 'opacity-50 cursor-not-allowed'
              )}
            >
              <Briefcase className="w-6 h-6 mb-2 text-secondary-600" />
              <div className="font-semibold text-surface-900">עסקי</div>
              <div className="text-sm text-surface-500">
                {canCreateBusiness ? 'ניהול הוצאות העסק' : 'זמין ב-Pro+Business'}
              </div>
            </button>
          </div>
        </div>
        
        {/* Workspace Name */}
        <Input
          label="שם ה-Workspace"
          placeholder={type === 'business' ? 'שם העסק שלי' : 'תקציב משפחתי'}
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        
        {/* Icon Selection */}
        <div>
          <label className="label">אייקון</label>
          <div className="flex flex-wrap gap-2">
            {WORKSPACE_ICONS.map((i) => (
              <button
                key={i}
                type="button"
                onClick={() => setIcon(i)}
                className={cn(
                  'w-10 h-10 rounded-lg text-xl flex items-center justify-center',
                  'transition-all',
                  icon === i
                    ? 'ring-2 ring-primary-500 ring-offset-2 bg-primary-50'
                    : 'bg-surface-100 hover:bg-surface-200'
                )}
              >
                {i}
              </button>
            ))}
          </div>
        </div>
        
        {/* Color Selection */}
        <div>
          <label className="label">צבע</label>
          <div className="flex flex-wrap gap-2">
            {WORKSPACE_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={cn(
                  'w-8 h-8 rounded-full transition-all',
                  color === c && 'ring-2 ring-offset-2 ring-surface-900'
                )}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>
        
        {/* Preview */}
        <div className="p-4 bg-surface-50 rounded-xl">
          <div className="text-xs text-surface-500 mb-2">תצוגה מקדימה</div>
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center text-xl"
              style={{ backgroundColor: hexToRgba(color, 0.15) }}
            >
              {icon}
            </div>
            <div>
              <div className="font-medium text-surface-900">
                {name || (type === 'business' ? 'שם העסק שלי' : 'תקציב משפחתי')}
              </div>
              <div className="text-xs text-surface-500">
                {type === 'business' ? 'עסקי' : 'אישי'}
              </div>
            </div>
          </div>
        </div>
        
        {/* Actions */}
        <div className="flex gap-3 justify-end pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>
            ביטול
          </Button>
          <Button type="submit" isLoading={isLoading}>
            יצירה
          </Button>
        </div>
      </form>
    </Modal>
  );
}
