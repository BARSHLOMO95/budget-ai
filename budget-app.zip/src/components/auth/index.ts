export { LoginPage } from './LoginPage';
export { SignUpPage } from './SignUpPage';
