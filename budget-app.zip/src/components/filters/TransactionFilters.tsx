import { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Calendar,
  Filter,
  Search,
  X,
  SlidersHorizontal,
} from 'lucide-react';
import { Button, Input, Select, Badge } from '@/components/ui';
import { Drawer } from '@/components/ui/Modal';
import { useCategoryOptions } from '@/hooks';
import { cn, formatMonth, MONTH_NAMES_HE } from '@/utils';
import type { QuickFilters, AdvancedFilters, TransactionType, CategoryGroup } from '@/types';

interface TransactionFiltersProps {
  quickFilters: QuickFilters;
  advancedFilters: AdvancedFilters;
  onQuickFilterChange: (filters: Partial<QuickFilters>) => void;
  onAdvancedFilterChange: (filters: Partial<AdvancedFilters>) => void;
  onReset: () => void;
  transactionCount?: number;
}

export function TransactionFilters({
  quickFilters,
  advancedFilters,
  onQuickFilterChange,
  onAdvancedFilterChange,
  onReset,
  transactionCount,
}: TransactionFiltersProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const { options: categoryOptions } = useCategoryOptions(
    quickFilters.type !== 'all' ? quickFilters.type : undefined
  );
  
  const hasActiveAdvancedFilters =
    advancedFilters.search ||
    advancedFilters.dateFrom ||
    advancedFilters.dateTo ||
    advancedFilters.amountMin !== null ||
    advancedFilters.amountMax !== null ||
    advancedFilters.tags.length > 0;
  
  // Navigate months
  const goToPreviousMonth = () => {
    let newMonth = quickFilters.month - 1;
    let newYear = quickFilters.year;
    if (newMonth < 0) {
      newMonth = 11;
      newYear--;
    }
    onQuickFilterChange({ month: newMonth, year: newYear });
  };
  
  const goToNextMonth = () => {
    let newMonth = quickFilters.month + 1;
    let newYear = quickFilters.year;
    if (newMonth > 11) {
      newMonth = 0;
      newYear++;
    }
    onQuickFilterChange({ month: newMonth, year: newYear });
  };
  
  const goToToday = () => {
    const now = new Date();
    onQuickFilterChange({ month: now.getMonth(), year: now.getFullYear() });
  };
  
  const isCurrentMonth =
    quickFilters.month === new Date().getMonth() &&
    quickFilters.year === new Date().getFullYear();
  
  return (
    <>
      <div className="space-y-4">
        {/* Month Navigation */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={goToPreviousMonth}
              className="p-2 rounded-lg hover:bg-surface-100 transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-surface-600" />
            </button>
            
            <div className="min-w-[140px] text-center">
              <span className="font-display font-semibold text-lg text-surface-900">
                {formatMonth(quickFilters.month, quickFilters.year)}
              </span>
            </div>
            
            <button
              onClick={goToNextMonth}
              className="p-2 rounded-lg hover:bg-surface-100 transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-surface-600" />
            </button>
            
            {!isCurrentMonth && (
              <Button
                variant="ghost"
                size="sm"
                onClick={goToToday}
                className="mr-2"
              >
                היום
              </Button>
            )}
          </div>
          
          {/* Transaction count */}
          {transactionCount !== undefined && (
            <span className="text-sm text-surface-500">
              {transactionCount} פעולות
            </span>
          )}
        </div>
        
        {/* Quick Filters Bar */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Type filter */}
          <div className="flex p-1 bg-surface-100 rounded-lg">
            {(['all', 'expense', 'income'] as const).map((type) => (
              <button
                key={type}
                onClick={() => onQuickFilterChange({ type })}
                className={cn(
                  'px-3 py-1.5 text-sm font-medium rounded-md transition-all',
                  quickFilters.type === type
                    ? 'bg-white shadow-sm text-surface-900'
                    : 'text-surface-500 hover:text-surface-700'
                )}
              >
                {type === 'all' ? 'הכל' : type === 'expense' ? 'הוצאות' : 'הכנסות'}
              </button>
            ))}
          </div>
          
          {/* Group filter (fixed/variable) */}
          <div className="flex p-1 bg-surface-100 rounded-lg">
            {(['all', 'fixed', 'variable'] as const).map((group) => (
              <button
                key={group}
                onClick={() => onQuickFilterChange({ group })}
                className={cn(
                  'px-3 py-1.5 text-sm font-medium rounded-md transition-all',
                  quickFilters.group === group
                    ? 'bg-white shadow-sm text-surface-900'
                    : 'text-surface-500 hover:text-surface-700'
                )}
              >
                {group === 'all' ? 'הכל' : group === 'fixed' ? 'קבועות' : 'משתנות'}
              </button>
            ))}
          </div>
          
          {/* Category filter */}
          <Select
            value={quickFilters.categoryId}
            onChange={(e) => onQuickFilterChange({ categoryId: e.target.value })}
            options={[
              { value: 'all', label: 'כל הקטגוריות' },
              ...categoryOptions.map((cat) => ({
                value: cat.value,
                label: `${cat.icon} ${cat.label}`,
              })),
            ]}
            className="w-44"
          />
          
          {/* Search */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
            <input
              type="text"
              placeholder="חיפוש בתיאור, הערות, תגיות..."
              value={advancedFilters.search}
              onChange={(e) => onAdvancedFilterChange({ search: e.target.value })}
              className="input pr-10 py-2"
            />
            {advancedFilters.search && (
              <button
                onClick={() => onAdvancedFilterChange({ search: '' })}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400 hover:text-surface-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          
          {/* Advanced Filters Toggle */}
          <Button
            variant={hasActiveAdvancedFilters ? 'primary' : 'secondary'}
            size="sm"
            onClick={() => setShowAdvanced(true)}
            leftIcon={<SlidersHorizontal className="w-4 h-4" />}
          >
            {hasActiveAdvancedFilters ? 'מסננים פעילים' : 'מסננים מתקדמים'}
          </Button>
          
          {/* Reset */}
          {(hasActiveAdvancedFilters ||
            quickFilters.type !== 'all' ||
            quickFilters.group !== 'all' ||
            quickFilters.categoryId !== 'all') && (
            <Button variant="ghost" size="sm" onClick={onReset}>
              איפוס
            </Button>
          )}
        </div>
        
        {/* Active filters display */}
        {hasActiveAdvancedFilters && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm text-surface-500">מסננים פעילים:</span>
            
            {advancedFilters.search && (
              <Badge variant="primary">
                חיפוש: "{advancedFilters.search}"
                <button
                  onClick={() => onAdvancedFilterChange({ search: '' })}
                  className="mr-1"
                >
                  ×
                </button>
              </Badge>
            )}
            
            {advancedFilters.dateFrom && (
              <Badge variant="primary">
                מתאריך: {advancedFilters.dateFrom.toLocaleDateString('he-IL')}
                <button
                  onClick={() => onAdvancedFilterChange({ dateFrom: null })}
                  className="mr-1"
                >
                  ×
                </button>
              </Badge>
            )}
            
            {advancedFilters.dateTo && (
              <Badge variant="primary">
                עד תאריך: {advancedFilters.dateTo.toLocaleDateString('he-IL')}
                <button
                  onClick={() => onAdvancedFilterChange({ dateTo: null })}
                  className="mr-1"
                >
                  ×
                </button>
              </Badge>
            )}
            
            {advancedFilters.amountMin !== null && (
              <Badge variant="primary">
                מינימום: ₪{advancedFilters.amountMin}
                <button
                  onClick={() => onAdvancedFilterChange({ amountMin: null })}
                  className="mr-1"
                >
                  ×
                </button>
              </Badge>
            )}
            
            {advancedFilters.amountMax !== null && (
              <Badge variant="primary">
                מקסימום: ₪{advancedFilters.amountMax}
                <button
                  onClick={() => onAdvancedFilterChange({ amountMax: null })}
                  className="mr-1"
                >
                  ×
                </button>
              </Badge>
            )}
            
            {advancedFilters.tags.map((tag) => (
              <Badge key={tag} variant="primary">
                תגית: {tag}
                <button
                  onClick={() =>
                    onAdvancedFilterChange({
                      tags: advancedFilters.tags.filter((t) => t !== tag),
                    })
                  }
                  className="mr-1"
                >
                  ×
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>
      
      {/* Advanced Filters Drawer */}
      <AdvancedFiltersDrawer
        isOpen={showAdvanced}
        onClose={() => setShowAdvanced(false)}
        filters={advancedFilters}
        onChange={onAdvancedFilterChange}
        onReset={() => {
          onAdvancedFilterChange({
            dateFrom: null,
            dateTo: null,
            amountMin: null,
            amountMax: null,
            search: '',
            tags: [],
          });
        }}
      />
    </>
  );
}

// ============================================================
// ADVANCED FILTERS DRAWER
// ============================================================

interface AdvancedFiltersDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  filters: AdvancedFilters;
  onChange: (filters: Partial<AdvancedFilters>) => void;
  onReset: () => void;
}

function AdvancedFiltersDrawer({
  isOpen,
  onClose,
  filters,
  onChange,
  onReset,
}: AdvancedFiltersDrawerProps) {
  const [tagInput, setTagInput] = useState('');
  
  const addTag = () => {
    if (tagInput.trim() && !filters.tags.includes(tagInput.trim())) {
      onChange({ tags: [...filters.tags, tagInput.trim()] });
      setTagInput('');
    }
  };
  
  return (
    <Drawer isOpen={isOpen} onClose={onClose} title="מסננים מתקדמים" size="md">
      <div className="p-6 space-y-6">
        {/* Date Range */}
        <div>
          <label className="label">טווח תאריכים</label>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-surface-500 mb-1 block">מתאריך</label>
              <input
                type="date"
                value={filters.dateFrom?.toISOString().split('T')[0] || ''}
                onChange={(e) =>
                  onChange({
                    dateFrom: e.target.value ? new Date(e.target.value) : null,
                  })
                }
                className="input"
              />
            </div>
            <div>
              <label className="text-xs text-surface-500 mb-1 block">עד תאריך</label>
              <input
                type="date"
                value={filters.dateTo?.toISOString().split('T')[0] || ''}
                onChange={(e) =>
                  onChange({
                    dateTo: e.target.value ? new Date(e.target.value) : null,
                  })
                }
                className="input"
              />
            </div>
          </div>
        </div>
        
        {/* Amount Range */}
        <div>
          <label className="label">טווח סכומים</label>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-surface-500 mb-1 block">מינימום</label>
              <input
                type="number"
                placeholder="0"
                value={filters.amountMin ?? ''}
                onChange={(e) =>
                  onChange({
                    amountMin: e.target.value ? parseFloat(e.target.value) : null,
                  })
                }
                className="input"
                min="0"
                dir="ltr"
              />
            </div>
            <div>
              <label className="text-xs text-surface-500 mb-1 block">מקסימום</label>
              <input
                type="number"
                placeholder="∞"
                value={filters.amountMax ?? ''}
                onChange={(e) =>
                  onChange({
                    amountMax: e.target.value ? parseFloat(e.target.value) : null,
                  })
                }
                className="input"
                min="0"
                dir="ltr"
              />
            </div>
          </div>
        </div>
        
        {/* Tags */}
        <div>
          <label className="label">תגיות</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addTag();
                }
              }}
              placeholder="הוסף תגית לסינון..."
              className="input flex-1"
            />
            <Button variant="secondary" onClick={addTag}>
              הוסף
            </Button>
          </div>
          {filters.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {filters.tags.map((tag) => (
                <Badge key={tag} variant="primary">
                  {tag}
                  <button
                    onClick={() =>
                      onChange({ tags: filters.tags.filter((t) => t !== tag) })
                    }
                    className="mr-1"
                  >
                    ×
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>
        
        {/* Actions */}
        <div className="flex gap-3 pt-4 border-t border-surface-100">
          <Button variant="secondary" onClick={onReset} className="flex-1">
            איפוס הכל
          </Button>
          <Button onClick={onClose} className="flex-1">
            החל מסננים
          </Button>
        </div>
      </div>
    </Drawer>
  );
}
