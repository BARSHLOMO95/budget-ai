import { useState, useEffect, useCallback, useMemo } from 'react';
import type {
  Transaction,
  TransactionWithCategory,
  TransactionType,
  TransactionFilters,
  QuickFilters,
  AdvancedFilters,
} from '@/types';
import {
  getTransactionsByDateRange,
  createTransaction,
  updateTransaction,
  deleteTransaction,
  deleteMultipleTransactions,
} from '@/services/transaction.service';
import { useWorkspace } from './useWorkspace';
import { useCategories } from './useCategories';
import { useAuth } from './useAuth';
import {
  applyQuickFilters,
  applyAdvancedFilters,
  enrichTransactionsWithCategories,
  getDefaultFilters,
} from '@/lib/calculations';
import { getMonthRange, debounce } from '@/utils';

// ============================================================
// TRANSACTIONS HOOK
// ============================================================

interface UseTransactionsOptions {
  autoFetch?: boolean;
}

interface UseTransactionsReturn {
  transactions: Transaction[];
  transactionsWithCategories: TransactionWithCategory[];
  filteredTransactions: TransactionWithCategory[];
  filters: TransactionFilters;
  isLoading: boolean;
  isFetching: boolean;
  error: string | null;
  hasMore: boolean;
  
  // Actions
  setQuickFilters: (filters: Partial<QuickFilters>) => void;
  setAdvancedFilters: (filters: Partial<AdvancedFilters>) => void;
  resetFilters: () => void;
  addTransaction: (data: TransactionInput) => Promise<Transaction>;
  editTransaction: (id: string, updates: Partial<TransactionInput>) => Promise<void>;
  removeTransaction: (id: string) => Promise<void>;
  removeMultipleTransactions: (ids: string[]) => Promise<void>;
  refresh: () => Promise<void>;
  loadMore: () => Promise<void>;
}

interface TransactionInput {
  type: TransactionType;
  amount: number;
  categoryId: string;
  description: string;
  date: Date;
  isRecurring?: boolean;
  tags?: string[];
  notes?: string;
}

export function useTransactions(options: UseTransactionsOptions = {}): UseTransactionsReturn {
  const { autoFetch = true } = options;
  const { currentWorkspace } = useWorkspace();
  const { categories } = useCategories();
  const { firebaseUser } = useAuth();
  
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filters, setFilters] = useState<TransactionFilters>(getDefaultFilters());
  const [isLoading, setIsLoading] = useState(true);
  const [isFetching, setIsFetching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [lastDoc, setLastDoc] = useState<unknown>(null);
  
  // Get date range from quick filters
  const dateRange = useMemo(() => {
    return getMonthRange(filters.quick.month, filters.quick.year);
  }, [filters.quick.month, filters.quick.year]);
  
  // Fetch transactions
  const fetchTransactions = useCallback(async (append = false) => {
    if (!currentWorkspace) {
      setTransactions([]);
      setIsLoading(false);
      return;
    }
    
    if (!append) {
      setIsLoading(true);
    }
    setIsFetching(true);
    setError(null);
    
    try {
      const response = await getTransactionsByDateRange(
        currentWorkspace.id,
        dateRange.start,
        dateRange.end,
        {
          limitCount: 50,
          afterDoc: append ? (lastDoc as undefined) : undefined,
        }
      );
      
      if (append) {
        setTransactions((prev) => [...prev, ...response.items]);
      } else {
        setTransactions(response.items);
      }
      
      setHasMore(response.hasMore);
      setLastDoc(response.lastDoc);
    } catch (err) {
      console.error('Failed to fetch transactions:', err);
      setError('שגיאה בטעינת הפעולות');
    } finally {
      setIsLoading(false);
      setIsFetching(false);
    }
  }, [currentWorkspace, dateRange]);
  
  // Initial fetch and refetch on filter changes
  useEffect(() => {
    if (autoFetch) {
      fetchTransactions(false);
    }
  }, [autoFetch, fetchTransactions]);
  
  // Enrich transactions with category data
  const transactionsWithCategories = useMemo(() => {
    return enrichTransactionsWithCategories(transactions, categories);
  }, [transactions, categories]);
  
  // Apply client-side filters
  const filteredTransactions = useMemo(() => {
    let result = applyQuickFilters(transactions, categories, filters.quick);
    result = applyAdvancedFilters(result, filters.advanced);
    return enrichTransactionsWithCategories(result, categories);
  }, [transactions, categories, filters]);
  
  // Filter actions
  const setQuickFilters = useCallback((newFilters: Partial<QuickFilters>) => {
    setFilters((prev) => ({
      ...prev,
      quick: { ...prev.quick, ...newFilters },
    }));
    
    // If month/year changed, we need to refetch
    if (newFilters.month !== undefined || newFilters.year !== undefined) {
      setLastDoc(null);
    }
  }, []);
  
  const setAdvancedFilters = useCallback((newFilters: Partial<AdvancedFilters>) => {
    setFilters((prev) => ({
      ...prev,
      advanced: { ...prev.advanced, ...newFilters },
    }));
  }, []);
  
  // Debounced search
  const debouncedSetSearch = useMemo(
    () =>
      debounce((search: string) => {
        setAdvancedFilters({ search });
      }, 300),
    [setAdvancedFilters]
  );
  
  const resetFilters = useCallback(() => {
    setFilters(getDefaultFilters());
    setLastDoc(null);
  }, []);
  
  // CRUD actions
  const addTransaction = useCallback(async (data: TransactionInput): Promise<Transaction> => {
    if (!currentWorkspace || !firebaseUser) {
      throw new Error('יש להתחבר ולבחור workspace');
    }
    
    const newTransaction = await createTransaction(
      currentWorkspace.id,
      firebaseUser.uid,
      data
    );
    
    // Add to local state if it falls within current date range
    const txDate = newTransaction.date;
    if (txDate >= dateRange.start && txDate <= dateRange.end) {
      setTransactions((prev) => [newTransaction, ...prev]);
    }
    
    return newTransaction;
  }, [currentWorkspace, firebaseUser, dateRange]);
  
  const editTransaction = useCallback(async (id: string, updates: Partial<TransactionInput>) => {
    if (!currentWorkspace) return;
    
    await updateTransaction(currentWorkspace.id, id, {
      ...updates,
      date: updates.date ? updates.date : undefined,
    });
    
    setTransactions((prev) =>
      prev.map((tx) =>
        tx.id === id
          ? {
              ...tx,
              ...updates,
              updatedAt: new Date(),
            }
          : tx
      )
    );
  }, [currentWorkspace]);
  
  const removeTransaction = useCallback(async (id: string) => {
    if (!currentWorkspace) return;
    
    await deleteTransaction(currentWorkspace.id, id);
    setTransactions((prev) => prev.filter((tx) => tx.id !== id));
  }, [currentWorkspace]);
  
  const removeMultipleTransactions = useCallback(async (ids: string[]) => {
    if (!currentWorkspace) return;
    
    await deleteMultipleTransactions(currentWorkspace.id, ids);
    setTransactions((prev) => prev.filter((tx) => !ids.includes(tx.id)));
  }, [currentWorkspace]);
  
  const refresh = useCallback(async () => {
    setLastDoc(null);
    await fetchTransactions(false);
  }, [fetchTransactions]);
  
  const loadMore = useCallback(async () => {
    if (hasMore && !isFetching) {
      await fetchTransactions(true);
    }
  }, [hasMore, isFetching, fetchTransactions]);
  
  return {
    transactions,
    transactionsWithCategories,
    filteredTransactions,
    filters,
    isLoading,
    isFetching,
    error,
    hasMore,
    setQuickFilters,
    setAdvancedFilters,
    resetFilters,
    addTransaction,
    editTransaction,
    removeTransaction,
    removeMultipleTransactions,
    refresh,
    loadMore,
  };
}

// ============================================================
// TRANSACTION STATS HOOK
// ============================================================

export function useTransactionStats() {
  const { filteredTransactions } = useTransactions();
  const { categories } = useCategories();
  
  return useMemo(() => {
    const income = filteredTransactions
      .filter((tx) => tx.type === 'income')
      .reduce((sum, tx) => sum + tx.amount, 0);
    
    const expense = filteredTransactions
      .filter((tx) => tx.type === 'expense')
      .reduce((sum, tx) => sum + tx.amount, 0);
    
    const balance = income - expense;
    
    const fixedExpenses = filteredTransactions
      .filter((tx) => tx.type === 'expense' && tx.category?.group === 'fixed')
      .reduce((sum, tx) => sum + tx.amount, 0);
    
    const variableExpenses = filteredTransactions
      .filter((tx) => tx.type === 'expense' && tx.category?.group === 'variable')
      .reduce((sum, tx) => sum + tx.amount, 0);
    
    return {
      income,
      expense,
      balance,
      fixedExpenses,
      variableExpenses,
      transactionCount: filteredTransactions.length,
    };
  }, [filteredTransactions]);
}
