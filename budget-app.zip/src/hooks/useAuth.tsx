import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react';
import type { User as FirebaseUser } from 'firebase/auth';
import type { User } from '@/types';
import {
  subscribeToAuthState,
  getUserDocument,
  signUpWithEmail,
  signInWithEmail,
  signInWithGoogle,
  signOut,
  resetPassword,
  getAuthErrorMessage,
} from '@/services/auth.service';

// ============================================================
// AUTH CONTEXT TYPES
// ============================================================

interface AuthState {
  firebaseUser: FirebaseUser | null;
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

interface AuthActions {
  signUp: (email: string, password: string, displayName: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signInGoogle: () => Promise<void>;
  logOut: () => Promise<void>;
  forgotPassword: (email: string) => Promise<void>;
  refreshUser: () => Promise<void>;
}

interface AuthContextValue extends AuthState, AuthActions {}

// ============================================================
// AUTH CONTEXT
// ============================================================

const AuthContext = createContext<AuthContextValue | null>(null);

// ============================================================
// AUTH PROVIDER
// ============================================================

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch user document when Firebase user changes
  const fetchUserDocument = useCallback(async (fbUser: FirebaseUser | null) => {
    if (fbUser) {
      try {
        const userDoc = await getUserDocument(fbUser.uid);
        setUser(userDoc);
      } catch (error) {
        console.error('Failed to fetch user document:', error);
        setUser(null);
      }
    } else {
      setUser(null);
    }
  }, []);
  
  // Subscribe to auth state changes
  useEffect(() => {
    const unsubscribe = subscribeToAuthState(async (fbUser) => {
      setFirebaseUser(fbUser);
      await fetchUserDocument(fbUser);
      setIsLoading(false);
    });
    
    return () => unsubscribe();
  }, [fetchUserDocument]);
  
  // Auth actions
  const signUp = useCallback(async (email: string, password: string, displayName: string) => {
    try {
      const fbUser = await signUpWithEmail(email, password, displayName);
      await fetchUserDocument(fbUser);
    } catch (error: unknown) {
      const errorCode = (error as { code?: string }).code || '';
      throw new Error(getAuthErrorMessage(errorCode));
    }
  }, [fetchUserDocument]);
  
  const signIn = useCallback(async (email: string, password: string) => {
    try {
      await signInWithEmail(email, password);
    } catch (error: unknown) {
      const errorCode = (error as { code?: string }).code || '';
      throw new Error(getAuthErrorMessage(errorCode));
    }
  }, []);
  
  const signInGoogle = useCallback(async () => {
    try {
      const fbUser = await signInWithGoogle();
      await fetchUserDocument(fbUser);
    } catch (error: unknown) {
      const errorCode = (error as { code?: string }).code || '';
      throw new Error(getAuthErrorMessage(errorCode));
    }
  }, [fetchUserDocument]);
  
  const logOut = useCallback(async () => {
    await signOut();
    setUser(null);
  }, []);
  
  const forgotPassword = useCallback(async (email: string) => {
    try {
      await resetPassword(email);
    } catch (error: unknown) {
      const errorCode = (error as { code?: string }).code || '';
      throw new Error(getAuthErrorMessage(errorCode));
    }
  }, []);
  
  const refreshUser = useCallback(async () => {
    if (firebaseUser) {
      await fetchUserDocument(firebaseUser);
    }
  }, [firebaseUser, fetchUserDocument]);
  
  const value: AuthContextValue = {
    firebaseUser,
    user,
    isLoading,
    isAuthenticated: !!firebaseUser,
    signUp,
    signIn,
    signInGoogle,
    logOut,
    forgotPassword,
    refreshUser,
  };
  
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// ============================================================
// AUTH HOOK
// ============================================================

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
}

// ============================================================
// REQUIRE AUTH HOOK
// ============================================================

export function useRequireAuth() {
  const { isAuthenticated, isLoading, user } = useAuth();
  
  return {
    isAuthenticated,
    isLoading,
    user,
    isReady: !isLoading && isAuthenticated,
  };
}
