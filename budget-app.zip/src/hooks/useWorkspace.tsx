import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react';
import type { Workspace, WorkspaceMember, WorkspaceType, Currency } from '@/types';
import {
  getUserWorkspaces,
  getWorkspace,
  createWorkspace,
  updateWorkspace,
  deleteWorkspace,
  getWorkspaceMembers,
  canUserCreateWorkspace,
} from '@/services/workspace.service';
import { updateUserDocument } from '@/services/auth.service';
import { useAuth } from './useAuth';
import { getLocalStorage, setLocalStorage } from '@/utils';

// ============================================================
// WORKSPACE CONTEXT TYPES
// ============================================================

interface WorkspaceState {
  workspaces: Workspace[];
  currentWorkspace: Workspace | null;
  members: WorkspaceMember[];
  isLoading: boolean;
  isLoadingMembers: boolean;
  error: string | null;
}

interface WorkspaceActions {
  switchWorkspace: (workspaceId: string) => Promise<void>;
  createNewWorkspace: (data: {
    name: string;
    type: WorkspaceType;
    currency?: Currency;
    icon?: string;
    color?: string;
  }) => Promise<Workspace>;
  updateCurrentWorkspace: (updates: Partial<Pick<Workspace, 'name' | 'icon' | 'color'>>) => Promise<void>;
  deleteCurrentWorkspace: () => Promise<void>;
  refreshWorkspaces: () => Promise<void>;
  refreshMembers: () => Promise<void>;
}

interface WorkspaceContextValue extends WorkspaceState, WorkspaceActions {}

// ============================================================
// WORKSPACE CONTEXT
// ============================================================

const WorkspaceContext = createContext<WorkspaceContextValue | null>(null);

const LAST_WORKSPACE_KEY = 'budget_last_workspace';

// ============================================================
// WORKSPACE PROVIDER
// ============================================================

interface WorkspaceProviderProps {
  children: ReactNode;
}

export function WorkspaceProvider({ children }: WorkspaceProviderProps) {
  const { user, firebaseUser, isAuthenticated } = useAuth();
  
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [currentWorkspace, setCurrentWorkspace] = useState<Workspace | null>(null);
  const [members, setMembers] = useState<WorkspaceMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingMembers, setIsLoadingMembers] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Fetch user's workspaces
  const fetchWorkspaces = useCallback(async () => {
    if (!firebaseUser) {
      setWorkspaces([]);
      setCurrentWorkspace(null);
      setIsLoading(false);
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      const userWorkspaces = await getUserWorkspaces(firebaseUser.uid);
      setWorkspaces(userWorkspaces);
      
      // If no workspaces, create default personal workspace
      if (userWorkspaces.length === 0) {
        const newWorkspace = await createWorkspace(
          firebaseUser.uid,
          firebaseUser.email || '',
          firebaseUser.displayName,
          {
            name: 'תקציב משפחתי',
            type: 'personal',
            currency: 'ILS',
          }
        );
        
        setWorkspaces([newWorkspace]);
        setCurrentWorkspace(newWorkspace);
        
        // Set as default workspace
        await updateUserDocument(firebaseUser.uid, {
          defaultWorkspaceId: newWorkspace.id,
        });
        
        setLocalStorage(LAST_WORKSPACE_KEY, newWorkspace.id);
      } else {
        // Determine which workspace to show
        const lastWorkspaceId = getLocalStorage<string | null>(LAST_WORKSPACE_KEY, null);
        const defaultWorkspaceId = user?.defaultWorkspaceId;
        
        let selectedWorkspace = userWorkspaces.find(
          (w) => w.id === lastWorkspaceId || w.id === defaultWorkspaceId
        );
        
        if (!selectedWorkspace) {
          selectedWorkspace = userWorkspaces[0];
        }
        
        setCurrentWorkspace(selectedWorkspace);
        setLocalStorage(LAST_WORKSPACE_KEY, selectedWorkspace.id);
      }
    } catch (err) {
      console.error('Failed to fetch workspaces:', err);
      setError('שגיאה בטעינת ה-workspaces');
    } finally {
      setIsLoading(false);
    }
  }, [firebaseUser, user?.defaultWorkspaceId]);
  
  // Fetch members when workspace changes
  const fetchMembers = useCallback(async () => {
    if (!currentWorkspace) {
      setMembers([]);
      return;
    }
    
    setIsLoadingMembers(true);
    
    try {
      const workspaceMembers = await getWorkspaceMembers(currentWorkspace.id);
      setMembers(workspaceMembers);
    } catch (err) {
      console.error('Failed to fetch members:', err);
    } finally {
      setIsLoadingMembers(false);
    }
  }, [currentWorkspace]);
  
  // Initial fetch
  useEffect(() => {
    if (isAuthenticated) {
      fetchWorkspaces();
    } else {
      setWorkspaces([]);
      setCurrentWorkspace(null);
      setIsLoading(false);
    }
  }, [isAuthenticated, fetchWorkspaces]);
  
  // Fetch members when workspace changes
  useEffect(() => {
    fetchMembers();
  }, [currentWorkspace?.id, fetchMembers]);
  
  // Actions
  const switchWorkspace = useCallback(async (workspaceId: string) => {
    const workspace = workspaces.find((w) => w.id === workspaceId);
    
    if (workspace) {
      setCurrentWorkspace(workspace);
      setLocalStorage(LAST_WORKSPACE_KEY, workspaceId);
    } else {
      // Workspace not in list, try to fetch it
      const fetchedWorkspace = await getWorkspace(workspaceId);
      if (fetchedWorkspace) {
        setCurrentWorkspace(fetchedWorkspace);
        setLocalStorage(LAST_WORKSPACE_KEY, workspaceId);
      }
    }
  }, [workspaces]);
  
  const createNewWorkspace = useCallback(async (data: {
    name: string;
    type: WorkspaceType;
    currency?: Currency;
    icon?: string;
    color?: string;
  }) => {
    if (!firebaseUser || !user) {
      throw new Error('יש להתחבר כדי ליצור workspace');
    }
    
    // Check if user can create workspace
    const validation = canUserCreateWorkspace(user.plan, workspaces.length, data.type);
    if (!validation.allowed) {
      throw new Error(validation.reason);
    }
    
    const newWorkspace = await createWorkspace(
      firebaseUser.uid,
      firebaseUser.email || '',
      firebaseUser.displayName,
      data
    );
    
    setWorkspaces((prev) => [...prev, newWorkspace]);
    setCurrentWorkspace(newWorkspace);
    setLocalStorage(LAST_WORKSPACE_KEY, newWorkspace.id);
    
    return newWorkspace;
  }, [firebaseUser, user, workspaces.length]);
  
  const updateCurrentWorkspace = useCallback(async (
    updates: Partial<Pick<Workspace, 'name' | 'icon' | 'color'>>
  ) => {
    if (!currentWorkspace) return;
    
    await updateWorkspace(currentWorkspace.id, updates);
    
    setCurrentWorkspace((prev) => prev ? { ...prev, ...updates } : null);
    setWorkspaces((prev) =>
      prev.map((w) => (w.id === currentWorkspace.id ? { ...w, ...updates } : w))
    );
  }, [currentWorkspace]);
  
  const deleteCurrentWorkspace = useCallback(async () => {
    if (!currentWorkspace || !firebaseUser) return;
    
    if (workspaces.length <= 1) {
      throw new Error('לא ניתן למחוק את ה-workspace היחיד');
    }
    
    await deleteWorkspace(currentWorkspace.id);
    
    const remainingWorkspaces = workspaces.filter((w) => w.id !== currentWorkspace.id);
    setWorkspaces(remainingWorkspaces);
    setCurrentWorkspace(remainingWorkspaces[0]);
    setLocalStorage(LAST_WORKSPACE_KEY, remainingWorkspaces[0].id);
  }, [currentWorkspace, firebaseUser, workspaces]);
  
  const refreshWorkspaces = useCallback(async () => {
    await fetchWorkspaces();
  }, [fetchWorkspaces]);
  
  const refreshMembers = useCallback(async () => {
    await fetchMembers();
  }, [fetchMembers]);
  
  const value: WorkspaceContextValue = {
    workspaces,
    currentWorkspace,
    members,
    isLoading,
    isLoadingMembers,
    error,
    switchWorkspace,
    createNewWorkspace,
    updateCurrentWorkspace,
    deleteCurrentWorkspace,
    refreshWorkspaces,
    refreshMembers,
  };
  
  return (
    <WorkspaceContext.Provider value={value}>
      {children}
    </WorkspaceContext.Provider>
  );
}

// ============================================================
// WORKSPACE HOOK
// ============================================================

export function useWorkspace(): WorkspaceContextValue {
  const context = useContext(WorkspaceContext);
  
  if (!context) {
    throw new Error('useWorkspace must be used within a WorkspaceProvider');
  }
  
  return context;
}

// ============================================================
// REQUIRE WORKSPACE HOOK
// ============================================================

export function useRequireWorkspace() {
  const { currentWorkspace, isLoading, error } = useWorkspace();
  
  return {
    workspace: currentWorkspace,
    isLoading,
    error,
    isReady: !isLoading && !!currentWorkspace,
  };
}
