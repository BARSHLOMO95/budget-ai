import { useState, useEffect, useCallback, useMemo } from 'react';
import type {
  Category,
  TransactionType,
  CategoryGroup,
} from '@/types';
import {
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  archiveCategory,
  unarchiveCategory,
  reorderCategories,
  groupCategoriesByType,
  groupCategoriesByTypeAndGroup,
} from '@/services/category.service';
import { useWorkspace } from './useWorkspace';

// ============================================================
// CATEGORIES HOOK
// ============================================================

interface UseCategoriesReturn {
  categories: Category[];
  categoriesByType: ReturnType<typeof groupCategoriesByType>;
  categoriesByTypeAndGroup: ReturnType<typeof groupCategoriesByTypeAndGroup>;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  addCategory: (data: CategoryInput) => Promise<Category>;
  editCategory: (id: string, updates: Partial<CategoryInput>) => Promise<void>;
  removeCategory: (id: string) => Promise<void>;
  archive: (id: string) => Promise<void>;
  unarchive: (id: string) => Promise<void>;
  reorder: (categoryIds: string[]) => Promise<void>;
  refresh: () => Promise<void>;
  
  // Helpers
  getCategoryById: (id: string) => Category | undefined;
  getCategoriesByType: (type: TransactionType) => Category[];
  getCategoriesByGroup: (group: CategoryGroup) => Category[];
}

interface CategoryInput {
  type: TransactionType;
  group: CategoryGroup;
  label: string;
  labelEn?: string;
  targetMonthly?: number | null;
  color: string;
  icon: string;
  order?: number;
}

export function useCategories(): UseCategoriesReturn {
  const { currentWorkspace } = useWorkspace();
  
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Fetch categories
  const fetchCategories = useCallback(async () => {
    if (!currentWorkspace) {
      setCategories([]);
      setIsLoading(false);
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      const workspaceCategories = await getCategories(currentWorkspace.id, {
        includeArchived: false,
      });
      setCategories(workspaceCategories);
    } catch (err) {
      console.error('Failed to fetch categories:', err);
      setError('שגיאה בטעינת הקטגוריות');
    } finally {
      setIsLoading(false);
    }
  }, [currentWorkspace]);
  
  // Initial fetch
  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);
  
  // Grouped categories
  const categoriesByType = useMemo(() => {
    return groupCategoriesByType(categories);
  }, [categories]);
  
  const categoriesByTypeAndGroup = useMemo(() => {
    return groupCategoriesByTypeAndGroup(categories);
  }, [categories]);
  
  // CRUD actions
  const addCategory = useCallback(async (data: CategoryInput): Promise<Category> => {
    if (!currentWorkspace) {
      throw new Error('יש לבחור workspace');
    }
    
    const newCategory = await createCategory(currentWorkspace.id, data);
    setCategories((prev) => [...prev, newCategory]);
    
    return newCategory;
  }, [currentWorkspace]);
  
  const editCategory = useCallback(async (id: string, updates: Partial<CategoryInput>) => {
    if (!currentWorkspace) return;
    
    await updateCategory(currentWorkspace.id, id, updates);
    
    setCategories((prev) =>
      prev.map((cat) =>
        cat.id === id
          ? { ...cat, ...updates, updatedAt: new Date() }
          : cat
      )
    );
  }, [currentWorkspace]);
  
  const removeCategory = useCallback(async (id: string) => {
    if (!currentWorkspace) return;
    
    await deleteCategory(currentWorkspace.id, id);
    setCategories((prev) => prev.filter((cat) => cat.id !== id));
  }, [currentWorkspace]);
  
  const archive = useCallback(async (id: string) => {
    if (!currentWorkspace) return;
    
    await archiveCategory(currentWorkspace.id, id);
    setCategories((prev) => prev.filter((cat) => cat.id !== id));
  }, [currentWorkspace]);
  
  const unarchive = useCallback(async (id: string) => {
    if (!currentWorkspace) return;
    
    await unarchiveCategory(currentWorkspace.id, id);
    await fetchCategories();
  }, [currentWorkspace, fetchCategories]);
  
  const reorder = useCallback(async (categoryIds: string[]) => {
    if (!currentWorkspace) return;
    
    await reorderCategories(currentWorkspace.id, categoryIds);
    
    // Update local state with new order
    setCategories((prev) => {
      const categoryMap = new Map(prev.map((cat) => [cat.id, cat]));
      return categoryIds
        .map((id, index) => {
          const cat = categoryMap.get(id);
          return cat ? { ...cat, order: index } : null;
        })
        .filter((cat): cat is Category => cat !== null);
    });
  }, [currentWorkspace]);
  
  const refresh = useCallback(async () => {
    await fetchCategories();
  }, [fetchCategories]);
  
  // Helpers
  const getCategoryById = useCallback((id: string) => {
    return categories.find((cat) => cat.id === id);
  }, [categories]);
  
  const getCategoriesByTypeFn = useCallback((type: TransactionType) => {
    return categories.filter((cat) => cat.type === type);
  }, [categories]);
  
  const getCategoriesByGroup = useCallback((group: CategoryGroup) => {
    return categories.filter((cat) => cat.group === group);
  }, [categories]);
  
  return {
    categories,
    categoriesByType,
    categoriesByTypeAndGroup,
    isLoading,
    error,
    addCategory,
    editCategory,
    removeCategory,
    archive,
    unarchive,
    reorder,
    refresh,
    getCategoryById,
    getCategoriesByType: getCategoriesByTypeFn,
    getCategoriesByGroup,
  };
}

// ============================================================
// CATEGORY OPTIONS HOOK (for selects)
// ============================================================

export function useCategoryOptions(type?: TransactionType) {
  const { categories, isLoading } = useCategories();
  
  const options = useMemo(() => {
    const filtered = type
      ? categories.filter((cat) => cat.type === type)
      : categories;
    
    return filtered.map((cat) => ({
      value: cat.id,
      label: cat.label,
      icon: cat.icon,
      color: cat.color,
      group: cat.group,
    }));
  }, [categories, type]);
  
  const groupedOptions = useMemo(() => {
    const filtered = type
      ? categories.filter((cat) => cat.type === type)
      : categories;
    
    const fixed = filtered.filter((cat) => cat.group === 'fixed');
    const variable = filtered.filter((cat) => cat.group === 'variable');
    
    return {
      fixed: fixed.map((cat) => ({
        value: cat.id,
        label: cat.label,
        icon: cat.icon,
        color: cat.color,
      })),
      variable: variable.map((cat) => ({
        value: cat.id,
        label: cat.label,
        icon: cat.icon,
        color: cat.color,
      })),
    };
  }, [categories, type]);
  
  return {
    options,
    groupedOptions,
    isLoading,
  };
}
