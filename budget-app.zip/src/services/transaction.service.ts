import {
  collection,
  doc,
  addDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  serverTimestamp,
  Timestamp,
  writeBatch,
  type DocumentSnapshot,
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type {
  Transaction,
  TransactionDoc,
  TransactionType,
  PaginatedResponse,
} from '@/types';

// ============================================================
// TRANSACTION OPERATIONS
// ============================================================

export async function createTransaction(
  workspaceId: string,
  userId: string,
  data: {
    type: TransactionType;
    amount: number;
    categoryId: string;
    description: string;
    date: Date;
    isRecurring?: boolean;
    recurringId?: string;
    tags?: string[];
    notes?: string;
  }
): Promise<Transaction> {
  const transactionsRef = collection(db, 'workspaces', workspaceId, 'transactions');
  
  const transactionData: TransactionDoc = {
    type: data.type,
    amount: Math.abs(data.amount), // Always store as positive
    categoryId: data.categoryId,
    description: data.description.trim(),
    date: Timestamp.fromDate(data.date),
    isRecurring: data.isRecurring || false,
    recurringId: data.recurringId,
    tags: data.tags || [],
    notes: data.notes,
    createdBy: userId,
    createdAt: serverTimestamp() as unknown as Timestamp,
    updatedAt: serverTimestamp() as unknown as Timestamp,
  };
  
  const docRef = await addDoc(transactionsRef, transactionData);
  
  return {
    id: docRef.id,
    workspaceId,
    ...transactionData,
    date: data.date,
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

export async function getTransaction(
  workspaceId: string,
  transactionId: string
): Promise<Transaction | null> {
  const transactionRef = doc(db, 'workspaces', workspaceId, 'transactions', transactionId);
  const transactionSnap = await getDoc(transactionRef);
  
  if (!transactionSnap.exists()) {
    return null;
  }
  
  const data = transactionSnap.data() as TransactionDoc;
  
  return {
    id: transactionSnap.id,
    workspaceId,
    type: data.type,
    amount: data.amount,
    categoryId: data.categoryId,
    description: data.description,
    date: data.date?.toDate() || new Date(),
    isRecurring: data.isRecurring,
    recurringId: data.recurringId,
    tags: data.tags,
    notes: data.notes,
    createdBy: data.createdBy,
    createdAt: data.createdAt?.toDate() || new Date(),
    updatedAt: data.updatedAt?.toDate() || new Date(),
  };
}

/**
 * Get transactions for a specific date range (optimized query)
 * This is the primary method for fetching transactions - always query by date range
 */
export async function getTransactionsByDateRange(
  workspaceId: string,
  startDate: Date,
  endDate: Date,
  options?: {
    type?: TransactionType;
    categoryId?: string;
    limitCount?: number;
    afterDoc?: DocumentSnapshot;
  }
): Promise<PaginatedResponse<Transaction>> {
  const transactionsRef = collection(db, 'workspaces', workspaceId, 'transactions');
  
  // Build query constraints
  const constraints = [
    where('date', '>=', Timestamp.fromDate(startDate)),
    where('date', '<=', Timestamp.fromDate(endDate)),
    orderBy('date', 'desc'),
  ];
  
  if (options?.type) {
    // Note: This requires a composite index
    constraints.push(where('type', '==', options.type));
  }
  
  if (options?.categoryId) {
    constraints.push(where('categoryId', '==', options.categoryId));
  }
  
  const pageSize = options?.limitCount || 50;
  constraints.push(limit(pageSize + 1)); // Fetch one extra to check if there are more
  
  if (options?.afterDoc) {
    constraints.push(startAfter(options.afterDoc));
  }
  
  const q = query(transactionsRef, ...constraints);
  const snapshot = await getDocs(q);
  
  const hasMore = snapshot.docs.length > pageSize;
  const docs = hasMore ? snapshot.docs.slice(0, pageSize) : snapshot.docs;
  
  const transactions: Transaction[] = docs.map((doc) => {
    const data = doc.data() as TransactionDoc;
    return {
      id: doc.id,
      workspaceId,
      type: data.type,
      amount: data.amount,
      categoryId: data.categoryId,
      description: data.description,
      date: data.date?.toDate() || new Date(),
      isRecurring: data.isRecurring,
      recurringId: data.recurringId,
      tags: data.tags || [],
      notes: data.notes,
      createdBy: data.createdBy,
      createdAt: data.createdAt?.toDate() || new Date(),
      updatedAt: data.updatedAt?.toDate() || new Date(),
    };
  });
  
  return {
    items: transactions,
    hasMore,
    lastDoc: docs[docs.length - 1],
  };
}

export async function updateTransaction(
  workspaceId: string,
  transactionId: string,
  updates: Partial<Omit<TransactionDoc, 'createdAt' | 'updatedAt' | 'createdBy'>>
): Promise<void> {
  const transactionRef = doc(db, 'workspaces', workspaceId, 'transactions', transactionId);
  
  const updateData: Record<string, unknown> = {
    ...updates,
    updatedAt: serverTimestamp(),
  };
  
  // Convert date to Timestamp if provided
  if (updates.date && updates.date instanceof Date) {
    updateData.date = Timestamp.fromDate(updates.date as unknown as Date);
  }
  
  await updateDoc(transactionRef, updateData);
}

export async function deleteTransaction(
  workspaceId: string,
  transactionId: string
): Promise<void> {
  const transactionRef = doc(db, 'workspaces', workspaceId, 'transactions', transactionId);
  await deleteDoc(transactionRef);
}

export async function deleteMultipleTransactions(
  workspaceId: string,
  transactionIds: string[]
): Promise<void> {
  const batch = writeBatch(db);
  
  for (const id of transactionIds) {
    const transactionRef = doc(db, 'workspaces', workspaceId, 'transactions', id);
    batch.delete(transactionRef);
  }
  
  await batch.commit();
}

// ============================================================
// BULK OPERATIONS
// ============================================================

export async function createMultipleTransactions(
  workspaceId: string,
  userId: string,
  transactions: Array<{
    type: TransactionType;
    amount: number;
    categoryId: string;
    description: string;
    date: Date;
    tags?: string[];
    notes?: string;
  }>
): Promise<Transaction[]> {
  const batch = writeBatch(db);
  const createdTransactions: Transaction[] = [];
  
  for (const tx of transactions) {
    const transactionRef = doc(collection(db, 'workspaces', workspaceId, 'transactions'));
    
    const transactionData: TransactionDoc = {
      type: tx.type,
      amount: Math.abs(tx.amount),
      categoryId: tx.categoryId,
      description: tx.description.trim(),
      date: Timestamp.fromDate(tx.date),
      isRecurring: false,
      tags: tx.tags || [],
      notes: tx.notes,
      createdBy: userId,
      createdAt: serverTimestamp() as unknown as Timestamp,
      updatedAt: serverTimestamp() as unknown as Timestamp,
    };
    
    batch.set(transactionRef, transactionData);
    
    createdTransactions.push({
      id: transactionRef.id,
      workspaceId,
      ...transactionData,
      date: tx.date,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }
  
  await batch.commit();
  
  return createdTransactions;
}

// ============================================================
// ANALYTICS QUERIES
// ============================================================

export async function getTransactionStats(
  workspaceId: string,
  startDate: Date,
  endDate: Date
): Promise<{
  totalIncome: number;
  totalExpense: number;
  transactionCount: number;
  avgTransactionAmount: number;
}> {
  const { items } = await getTransactionsByDateRange(
    workspaceId,
    startDate,
    endDate,
    { limitCount: 1000 } // Get all transactions for the period
  );
  
  const totalIncome = items
    .filter((tx) => tx.type === 'income')
    .reduce((sum, tx) => sum + tx.amount, 0);
  
  const totalExpense = items
    .filter((tx) => tx.type === 'expense')
    .reduce((sum, tx) => sum + tx.amount, 0);
  
  const allAmounts = items.map((tx) => tx.amount);
  const avgTransactionAmount = allAmounts.length > 0
    ? allAmounts.reduce((a, b) => a + b, 0) / allAmounts.length
    : 0;
  
  return {
    totalIncome,
    totalExpense,
    transactionCount: items.length,
    avgTransactionAmount,
  };
}

export async function getCategoryTotals(
  workspaceId: string,
  startDate: Date,
  endDate: Date
): Promise<Map<string, { income: number; expense: number; count: number }>> {
  const { items } = await getTransactionsByDateRange(
    workspaceId,
    startDate,
    endDate,
    { limitCount: 1000 }
  );
  
  const totals = new Map<string, { income: number; expense: number; count: number }>();
  
  for (const tx of items) {
    const current = totals.get(tx.categoryId) || { income: 0, expense: 0, count: 0 };
    
    if (tx.type === 'income') {
      current.income += tx.amount;
    } else {
      current.expense += tx.amount;
    }
    current.count += 1;
    
    totals.set(tx.categoryId, current);
  }
  
  return totals;
}
