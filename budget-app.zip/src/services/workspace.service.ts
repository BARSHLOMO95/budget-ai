import {
  collection,
  doc,
  addDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  serverTimestamp,
  writeBatch,
  Timestamp,
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type {
  Workspace,
  WorkspaceDoc,
  WorkspaceMember,
  WorkspaceMemberDoc,
  WorkspaceType,
  Currency,
  MemberRole,
  DEFAULT_CATEGORIES,
  CategoryDoc,
} from '@/types';
import { DEFAULT_CATEGORIES as defaultCategories } from '@/types';

// ============================================================
// WORKSPACE OPERATIONS
// ============================================================

export async function createWorkspace(
  ownerId: string,
  ownerEmail: string,
  ownerDisplayName: string | null,
  data: {
    name: string;
    type: WorkspaceType;
    currency?: Currency;
    icon?: string;
    color?: string;
  }
): Promise<Workspace> {
  const batch = writeBatch(db);
  
  // Create workspace document
  const workspaceRef = doc(collection(db, 'workspaces'));
  const workspaceData: WorkspaceDoc = {
    name: data.name,
    type: data.type,
    ownerId,
    currency: data.currency || 'ILS',
    icon: data.icon || (data.type === 'business' ? '💼' : '🏠'),
    color: data.color || (data.type === 'business' ? '#8b5cf6' : '#0c85f4'),
    createdAt: serverTimestamp() as unknown as Timestamp,
    updatedAt: serverTimestamp() as unknown as Timestamp,
  };
  
  batch.set(workspaceRef, workspaceData);
  
  // Add owner as member
  const memberRef = doc(db, 'workspaces', workspaceRef.id, 'members', ownerId);
  const memberData: WorkspaceMemberDoc = {
    userId: ownerId,
    role: 'owner',
    email: ownerEmail,
    displayName: ownerDisplayName,
    joinedAt: serverTimestamp() as unknown as Timestamp,
  };
  
  batch.set(memberRef, memberData);
  
  // Create default categories based on workspace type
  const categories = defaultCategories.filter((cat) => {
    // For business workspace, filter out personal categories
    if (data.type === 'business') {
      return !['שכירות / משכנתא', 'ועד בית', 'ילדים וחינוך', 'חיות מחמד'].includes(cat.label);
    }
    return true;
  });
  
  for (const category of categories) {
    const categoryRef = doc(collection(db, 'workspaces', workspaceRef.id, 'categories'));
    batch.set(categoryRef, {
      ...category,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }
  
  await batch.commit();
  
  return {
    id: workspaceRef.id,
    ...workspaceData,
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

export async function getWorkspace(workspaceId: string): Promise<Workspace | null> {
  const workspaceRef = doc(db, 'workspaces', workspaceId);
  const workspaceSnap = await getDoc(workspaceRef);
  
  if (!workspaceSnap.exists()) {
    return null;
  }
  
  const data = workspaceSnap.data() as WorkspaceDoc;
  
  return {
    id: workspaceSnap.id,
    name: data.name,
    type: data.type,
    ownerId: data.ownerId,
    currency: data.currency,
    icon: data.icon,
    color: data.color,
    createdAt: data.createdAt?.toDate() || new Date(),
    updatedAt: data.updatedAt?.toDate() || new Date(),
  };
}

export async function getUserWorkspaces(userId: string): Promise<Workspace[]> {
  // Get all workspaces where user is a member
  // First, we need to query all workspaces and check membership
  // This is a workaround since Firestore doesn't support collection group queries on subcollections with filters easily
  
  const workspacesRef = collection(db, 'workspaces');
  const workspacesSnap = await getDocs(workspacesRef);
  
  const workspaces: Workspace[] = [];
  
  for (const workspaceDoc of workspacesSnap.docs) {
    // Check if user is a member
    const memberRef = doc(db, 'workspaces', workspaceDoc.id, 'members', userId);
    const memberSnap = await getDoc(memberRef);
    
    if (memberSnap.exists()) {
      const data = workspaceDoc.data() as WorkspaceDoc;
      workspaces.push({
        id: workspaceDoc.id,
        name: data.name,
        type: data.type,
        ownerId: data.ownerId,
        currency: data.currency,
        icon: data.icon,
        color: data.color,
        createdAt: data.createdAt?.toDate() || new Date(),
        updatedAt: data.updatedAt?.toDate() || new Date(),
      });
    }
  }
  
  return workspaces;
}

export async function updateWorkspace(
  workspaceId: string,
  updates: Partial<Omit<WorkspaceDoc, 'createdAt' | 'updatedAt' | 'ownerId'>>
): Promise<void> {
  const workspaceRef = doc(db, 'workspaces', workspaceId);
  
  await updateDoc(workspaceRef, {
    ...updates,
    updatedAt: serverTimestamp(),
  });
}

export async function deleteWorkspace(workspaceId: string): Promise<void> {
  // Note: In production, you'd want to use a Cloud Function to delete subcollections
  const workspaceRef = doc(db, 'workspaces', workspaceId);
  await deleteDoc(workspaceRef);
}

// ============================================================
// MEMBER OPERATIONS
// ============================================================

export async function getWorkspaceMembers(workspaceId: string): Promise<WorkspaceMember[]> {
  const membersRef = collection(db, 'workspaces', workspaceId, 'members');
  const membersSnap = await getDocs(membersRef);
  
  return membersSnap.docs.map((doc) => {
    const data = doc.data() as WorkspaceMemberDoc;
    return {
      id: doc.id,
      workspaceId,
      userId: data.userId,
      role: data.role,
      email: data.email,
      displayName: data.displayName,
      joinedAt: data.joinedAt?.toDate() || new Date(),
    };
  });
}

export async function addWorkspaceMember(
  workspaceId: string,
  userId: string,
  email: string,
  displayName: string | null,
  role: MemberRole = 'member'
): Promise<WorkspaceMember> {
  const memberRef = doc(db, 'workspaces', workspaceId, 'members', userId);
  
  const memberData: WorkspaceMemberDoc = {
    userId,
    role,
    email,
    displayName,
    joinedAt: serverTimestamp() as unknown as Timestamp,
  };
  
  await updateDoc(memberRef, memberData);
  
  return {
    id: userId,
    workspaceId,
    userId,
    role,
    email,
    displayName,
    joinedAt: new Date(),
  };
}

export async function updateMemberRole(
  workspaceId: string,
  userId: string,
  role: MemberRole
): Promise<void> {
  const memberRef = doc(db, 'workspaces', workspaceId, 'members', userId);
  await updateDoc(memberRef, { role });
}

export async function removeMember(workspaceId: string, userId: string): Promise<void> {
  const memberRef = doc(db, 'workspaces', workspaceId, 'members', userId);
  await deleteDoc(memberRef);
}

export async function checkMembership(
  workspaceId: string,
  userId: string
): Promise<MemberRole | null> {
  const memberRef = doc(db, 'workspaces', workspaceId, 'members', userId);
  const memberSnap = await getDoc(memberRef);
  
  if (!memberSnap.exists()) {
    return null;
  }
  
  return (memberSnap.data() as WorkspaceMemberDoc).role;
}

// ============================================================
// WORKSPACE VALIDATION
// ============================================================

export function canUserCreateWorkspace(
  plan: string,
  currentWorkspaceCount: number,
  workspaceType: WorkspaceType
): { allowed: boolean; reason?: string } {
  const limits: Record<string, { max: number; allowsBusiness: boolean }> = {
    free: { max: 1, allowsBusiness: false },
    pro: { max: 3, allowsBusiness: false },
    pro_business: { max: 10, allowsBusiness: true },
  };
  
  const planLimits = limits[plan] || limits.free;
  
  if (currentWorkspaceCount >= planLimits.max) {
    return {
      allowed: false,
      reason: `הגעת למגבלת ה-${planLimits.max} workspaces בתוכנית שלך`,
    };
  }
  
  if (workspaceType === 'business' && !planLimits.allowsBusiness) {
    return {
      allowed: false,
      reason: 'workspace עסקי זמין רק בתוכנית Pro + Business',
    };
  }
  
  return { allowed: true };
}
