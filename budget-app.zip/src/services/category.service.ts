import {
  collection,
  doc,
  addDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
  writeBatch,
  Timestamp,
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type {
  Category,
  CategoryDoc,
  TransactionType,
  CategoryGroup,
} from '@/types';

// ============================================================
// CATEGORY OPERATIONS
// ============================================================

export async function createCategory(
  workspaceId: string,
  data: {
    type: TransactionType;
    group: CategoryGroup;
    label: string;
    labelEn?: string;
    targetMonthly?: number | null;
    color: string;
    icon: string;
    order?: number;
  }
): Promise<Category> {
  const categoriesRef = collection(db, 'workspaces', workspaceId, 'categories');
  
  // Get the highest order number for this type
  const existingQuery = query(
    categoriesRef,
    where('type', '==', data.type),
    orderBy('order', 'desc')
  );
  const existingSnap = await getDocs(existingQuery);
  
  const maxOrder = existingSnap.empty
    ? 0
    : (existingSnap.docs[0].data() as CategoryDoc).order + 1;
  
  const categoryData: CategoryDoc = {
    type: data.type,
    group: data.group,
    label: data.label.trim(),
    labelEn: data.labelEn?.trim(),
    targetMonthly: data.targetMonthly ?? null,
    color: data.color,
    icon: data.icon,
    order: data.order ?? maxOrder,
    isArchived: false,
    createdAt: serverTimestamp() as unknown as Timestamp,
    updatedAt: serverTimestamp() as unknown as Timestamp,
  };
  
  const docRef = await addDoc(categoriesRef, categoryData);
  
  return {
    id: docRef.id,
    workspaceId,
    ...categoryData,
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

export async function getCategory(
  workspaceId: string,
  categoryId: string
): Promise<Category | null> {
  const categoryRef = doc(db, 'workspaces', workspaceId, 'categories', categoryId);
  const categorySnap = await getDoc(categoryRef);
  
  if (!categorySnap.exists()) {
    return null;
  }
  
  const data = categorySnap.data() as CategoryDoc;
  
  return {
    id: categorySnap.id,
    workspaceId,
    type: data.type,
    group: data.group,
    label: data.label,
    labelEn: data.labelEn,
    targetMonthly: data.targetMonthly,
    color: data.color,
    icon: data.icon,
    order: data.order,
    isArchived: data.isArchived,
    createdAt: data.createdAt?.toDate() || new Date(),
    updatedAt: data.updatedAt?.toDate() || new Date(),
  };
}

export async function getCategories(
  workspaceId: string,
  options?: {
    type?: TransactionType;
    group?: CategoryGroup;
    includeArchived?: boolean;
  }
): Promise<Category[]> {
  const categoriesRef = collection(db, 'workspaces', workspaceId, 'categories');
  
  const constraints = [orderBy('order', 'asc')];
  
  if (options?.type) {
    constraints.unshift(where('type', '==', options.type));
  }
  
  if (options?.group) {
    constraints.unshift(where('group', '==', options.group));
  }
  
  if (!options?.includeArchived) {
    constraints.unshift(where('isArchived', '==', false));
  }
  
  const q = query(categoriesRef, ...constraints);
  const snapshot = await getDocs(q);
  
  return snapshot.docs.map((doc) => {
    const data = doc.data() as CategoryDoc;
    return {
      id: doc.id,
      workspaceId,
      type: data.type,
      group: data.group,
      label: data.label,
      labelEn: data.labelEn,
      targetMonthly: data.targetMonthly,
      color: data.color,
      icon: data.icon,
      order: data.order,
      isArchived: data.isArchived,
      createdAt: data.createdAt?.toDate() || new Date(),
      updatedAt: data.updatedAt?.toDate() || new Date(),
    };
  });
}

export async function updateCategory(
  workspaceId: string,
  categoryId: string,
  updates: Partial<Omit<CategoryDoc, 'createdAt' | 'updatedAt'>>
): Promise<void> {
  const categoryRef = doc(db, 'workspaces', workspaceId, 'categories', categoryId);
  
  await updateDoc(categoryRef, {
    ...updates,
    updatedAt: serverTimestamp(),
  });
}

export async function deleteCategory(
  workspaceId: string,
  categoryId: string
): Promise<void> {
  // In production, you might want to check if there are transactions using this category
  // and either prevent deletion or reassign them
  const categoryRef = doc(db, 'workspaces', workspaceId, 'categories', categoryId);
  await deleteDoc(categoryRef);
}

export async function archiveCategory(
  workspaceId: string,
  categoryId: string
): Promise<void> {
  await updateCategory(workspaceId, categoryId, { isArchived: true });
}

export async function unarchiveCategory(
  workspaceId: string,
  categoryId: string
): Promise<void> {
  await updateCategory(workspaceId, categoryId, { isArchived: false });
}

// ============================================================
// BULK OPERATIONS
// ============================================================

export async function reorderCategories(
  workspaceId: string,
  categoryIds: string[]
): Promise<void> {
  const batch = writeBatch(db);
  
  categoryIds.forEach((id, index) => {
    const categoryRef = doc(db, 'workspaces', workspaceId, 'categories', id);
    batch.update(categoryRef, {
      order: index,
      updatedAt: serverTimestamp(),
    });
  });
  
  await batch.commit();
}

export async function updateCategoryTargets(
  workspaceId: string,
  targets: Array<{ categoryId: string; targetMonthly: number | null }>
): Promise<void> {
  const batch = writeBatch(db);
  
  for (const { categoryId, targetMonthly } of targets) {
    const categoryRef = doc(db, 'workspaces', workspaceId, 'categories', categoryId);
    batch.update(categoryRef, {
      targetMonthly,
      updatedAt: serverTimestamp(),
    });
  }
  
  await batch.commit();
}

// ============================================================
// CATEGORY HELPERS
// ============================================================

export function getCategoryById(
  categories: Category[],
  categoryId: string
): Category | undefined {
  return categories.find((cat) => cat.id === categoryId);
}

export function getCategoriesByType(
  categories: Category[],
  type: TransactionType
): Category[] {
  return categories.filter((cat) => cat.type === type);
}

export function getCategoriesByGroup(
  categories: Category[],
  group: CategoryGroup
): Category[] {
  return categories.filter((cat) => cat.group === group);
}

export function groupCategoriesByType(
  categories: Category[]
): Record<TransactionType, Category[]> {
  return {
    income: categories.filter((cat) => cat.type === 'income'),
    expense: categories.filter((cat) => cat.type === 'expense'),
  };
}

export function groupCategoriesByTypeAndGroup(
  categories: Category[]
): Record<TransactionType, Record<CategoryGroup, Category[]>> {
  return {
    income: {
      fixed: categories.filter((cat) => cat.type === 'income' && cat.group === 'fixed'),
      variable: categories.filter((cat) => cat.type === 'income' && cat.group === 'variable'),
    },
    expense: {
      fixed: categories.filter((cat) => cat.type === 'expense' && cat.group === 'fixed'),
      variable: categories.filter((cat) => cat.type === 'expense' && cat.group === 'variable'),
    },
  };
}
