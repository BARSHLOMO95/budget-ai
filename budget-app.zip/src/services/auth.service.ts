import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged,
  type User as FirebaseUser,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';
import type { User, UserDoc, SubscriptionPlan } from '@/types';

const googleProvider = new GoogleAuthProvider();

// ============================================================
// AUTH OPERATIONS
// ============================================================

export async function signUpWithEmail(
  email: string,
  password: string,
  displayName: string
): Promise<FirebaseUser> {
  const { user } = await createUserWithEmailAndPassword(auth, email, password);
  
  // Update profile with display name
  await updateProfile(user, { displayName });
  
  // Create user document in Firestore
  await createUserDocument(user);
  
  return user;
}

export async function signInWithEmail(
  email: string,
  password: string
): Promise<FirebaseUser> {
  const { user } = await signInWithEmailAndPassword(auth, email, password);
  return user;
}

export async function signInWithGoogle(): Promise<FirebaseUser> {
  const { user } = await signInWithPopup(auth, googleProvider);
  
  // Check if user document exists, create if not
  const userRef = doc(db, 'users', user.uid);
  const userSnap = await getDoc(userRef);
  
  if (!userSnap.exists()) {
    await createUserDocument(user);
  }
  
  return user;
}

export async function signOut(): Promise<void> {
  await firebaseSignOut(auth);
}

export async function resetPassword(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email);
}

// ============================================================
// USER DOCUMENT OPERATIONS
// ============================================================

async function createUserDocument(firebaseUser: FirebaseUser): Promise<void> {
  const userRef = doc(db, 'users', firebaseUser.uid);
  
  const userData: Omit<UserDoc, 'createdAt' | 'updatedAt'> & {
    createdAt: ReturnType<typeof serverTimestamp>;
    updatedAt: ReturnType<typeof serverTimestamp>;
  } = {
    email: firebaseUser.email || '',
    displayName: firebaseUser.displayName,
    photoURL: firebaseUser.photoURL,
    plan: 'free' as SubscriptionPlan,
    defaultWorkspaceId: null,
    stripeCustomerId: null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  
  await setDoc(userRef, userData);
}

export async function getUserDocument(uid: string): Promise<User | null> {
  const userRef = doc(db, 'users', uid);
  const userSnap = await getDoc(userRef);
  
  if (!userSnap.exists()) {
    return null;
  }
  
  const data = userSnap.data() as UserDoc;
  
  return {
    uid,
    email: data.email,
    displayName: data.displayName,
    photoURL: data.photoURL,
    plan: data.plan,
    defaultWorkspaceId: data.defaultWorkspaceId,
    stripeCustomerId: data.stripeCustomerId,
    createdAt: data.createdAt?.toDate() || new Date(),
    updatedAt: data.updatedAt?.toDate() || new Date(),
  };
}

export async function updateUserDocument(
  uid: string,
  updates: Partial<Omit<UserDoc, 'createdAt' | 'updatedAt'>>
): Promise<void> {
  const userRef = doc(db, 'users', uid);
  
  await setDoc(
    userRef,
    {
      ...updates,
      updatedAt: serverTimestamp(),
    },
    { merge: true }
  );
}

// ============================================================
// AUTH STATE LISTENER
// ============================================================

export function subscribeToAuthState(
  callback: (user: FirebaseUser | null) => void
): () => void {
  return onAuthStateChanged(auth, callback);
}

// ============================================================
// AUTH ERROR MESSAGES (Hebrew)
// ============================================================

export function getAuthErrorMessage(errorCode: string): string {
  const errorMessages: Record<string, string> = {
    'auth/email-already-in-use': 'כתובת האימייל כבר בשימוש',
    'auth/invalid-email': 'כתובת אימייל לא תקינה',
    'auth/operation-not-allowed': 'פעולה זו אינה מורשית',
    'auth/weak-password': 'הסיסמה חלשה מדי. נדרשות לפחות 6 תווים',
    'auth/user-disabled': 'חשבון המשתמש הושבת',
    'auth/user-not-found': 'משתמש לא נמצא',
    'auth/wrong-password': 'סיסמה שגויה',
    'auth/invalid-credential': 'פרטי ההתחברות שגויים',
    'auth/too-many-requests': 'יותר מדי ניסיונות. נסה שוב מאוחר יותר',
    'auth/network-request-failed': 'בעיית חיבור לרשת',
    'auth/popup-closed-by-user': 'החלון נסגר לפני השלמת ההתחברות',
    'auth/requires-recent-login': 'נדרשת התחברות מחדש לביצוע פעולה זו',
  };
  
  return errorMessages[errorCode] || 'אירעה שגיאה. נסה שוב';
}
